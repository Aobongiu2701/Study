import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { 
  Plus, Paperclip, Trash2, Calendar, ListTodo, Clock, 
  Tag, FileText, ChevronDown, ChevronRight, CheckCircle2, 
  Circle, AlertCircle, CalendarDays, Timer, Camera, Image,
  BarChart3, TrendingUp, Activity, Target, Award
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Checkbox } from "@/components/ui/checkbox";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { useToast } from "@/hooks/use-toast";
import type { Task, InsertTask } from "@shared/schema";

interface TaskManagementProps {
  currentDate: string;
}

interface Subtask {
  id: string;
  title: string;
  completed: boolean;
}

interface Attachment {
  id: string;
  name: string;
  url: string;
  type: string;
  uploadedAt: string;
}

interface TaskResult {
  id: string;
  type: 'image' | 'text' | 'score';
  content: string;
  description?: string;
  addedAt: string;
}

const categories = [
  { value: "IELTS Listening", color: "bg-blue-100 text-blue-800", pastel: "var(--pastel-blue)" },
  { value: "IELTS Reading", color: "bg-green-100 text-green-800", pastel: "var(--pastel-green)" },
  { value: "IELTS Writing", color: "bg-purple-100 text-purple-800", pastel: "var(--pastel-purple)" },
  { value: "IELTS Speaking", color: "bg-pink-100 text-pink-800", pastel: "var(--pastel-pink)" },
  { value: "Từ vựng", color: "bg-yellow-100 text-yellow-800", pastel: "var(--pastel-yellow)" },
  { value: "Ngữ pháp", color: "bg-orange-100 text-orange-800", pastel: "var(--pastel-orange)" },
  { value: "Luyện thi", color: "bg-red-100 text-red-800", pastel: "var(--pastel-red)" },
  { value: "Khác", color: "bg-gray-100 text-gray-800", pastel: "var(--pastel-mint)" }
];

const priorities = [
  { value: "Cao", color: "bg-red-100 text-red-700 border-red-200", pastel: "var(--pastel-red)" },
  { value: "Trung bình", color: "bg-yellow-100 text-yellow-700 border-yellow-200", pastel: "var(--pastel-yellow)" },
  { value: "Thấp", color: "bg-green-100 text-green-700 border-green-200", pastel: "var(--pastel-green)" }
];

export default function TaskManagementPastel({ currentDate }: TaskManagementProps) {
  const [isAddingTask, setIsAddingTask] = useState(false);
  const [expandedTasks, setExpandedTasks] = useState<Set<number>>(new Set());
  const [filterCategory, setFilterCategory] = useState<string>("Tất cả");
  const [filterPriority, setFilterPriority] = useState<string>("Tất cả");
  const [sortBy, setSortBy] = useState<string>("created");
  const [showAnalytics, setShowAnalytics] = useState(false);

  // Form state
  const [newTask, setNewTask] = useState({
    title: "",
    description: "",
    priority: "Trung bình",
    category: "Khác",
    estimatedTime: 30,
    dueDate: "",
    tags: [] as string[],
    subtasks: [] as Subtask[],
    attachments: [] as Attachment[],
    results: [] as TaskResult[]
  });

  const { toast } = useToast();

  const { data: tasks = [], isLoading } = useQuery<Task[]>({
    queryKey: ['/api/tasks'],
  });

  const createTaskMutation = useMutation({
    mutationFn: async (task: InsertTask) => {
      const response = await apiRequest('POST', '/api/tasks', task);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/tasks'] });
      setIsAddingTask(false);
      resetForm();
      toast({
        title: "Thành công",
        description: "Đã thêm công việc mới",
      });
    },
  });

  const updateTaskMutation = useMutation({
    mutationFn: async ({ id, updates }: { id: number; updates: Partial<Task> }) => {
      const response = await apiRequest('PATCH', `/api/tasks/${id}`, updates);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/tasks'] });
    },
  });

  const deleteTaskMutation = useMutation({
    mutationFn: async (id: number) => {
      const response = await apiRequest('DELETE', `/api/tasks/${id}`);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/tasks'] });
      toast({
        title: "Đã xóa",
        description: "Công việc đã được xóa",
      });
    },
  });

  const resetForm = () => {
    setNewTask({
      title: "",
      description: "",
      priority: "Trung bình",
      category: "Khác",
      estimatedTime: 30,
      dueDate: "",
      tags: [],
      subtasks: [],
      attachments: [],
      results: []
    });
  };

  const handleAddTask = () => {
    if (!newTask.title.trim()) return;
    
    createTaskMutation.mutate({
      title: newTask.title,
      description: newTask.description || null,
      priority: newTask.priority,
      category: newTask.category,
      estimatedTime: newTask.estimatedTime,
      dueDate: newTask.dueDate ? new Date(newTask.dueDate) : null,
      tags: newTask.tags,
      subtasks: newTask.subtasks,
      attachments: newTask.attachments,
      results: newTask.results,
      completed: false,
    });
  };

  const handleToggleTask = (taskId: number, completed: boolean) => {
    updateTaskMutation.mutate({
      id: taskId,
      updates: { completed }
    });
  };

  const handleDeleteTask = (taskId: number) => {
    if (confirm('Bạn có chắc muốn xóa công việc này?')) {
      deleteTaskMutation.mutate(taskId);
    }
  };

  const handleImageUpload = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    const formData = new FormData();
    formData.append('image', file);

    try {
      const response = await fetch('/api/upload', {
        method: 'POST',
        body: formData,
      });
      
      if (response.ok) {
        const result = await response.json();
        const newAttachment: Attachment = {
          id: Date.now().toString(),
          name: file.name,
          url: result.url,
          type: file.type,
          uploadedAt: new Date().toISOString()
        };
        
        setNewTask(prev => ({
          ...prev,
          attachments: [...prev.attachments, newAttachment]
        }));
        
        toast({
          title: "Thành công",
          description: "Đã tải lên hình ảnh",
        });
      }
    } catch (error) {
      toast({
        title: "Lỗi",
        description: "Không thể tải lên hình ảnh",
        variant: "destructive"
      });
    }
  };

  const addTaskResult = (taskId: number, result: TaskResult) => {
    const task = tasks.find(t => t.id === taskId);
    if (!task) return;

    const currentResults = Array.isArray(task.results) ? task.results : [];
    const updatedResults = [...currentResults, result];

    updateTaskMutation.mutate({
      id: taskId,
      updates: { results: updatedResults }
    });
  };

  const addSubtask = () => {
    const newSubtask: Subtask = {
      id: Date.now().toString(),
      title: "",
      completed: false
    };
    setNewTask(prev => ({
      ...prev,
      subtasks: [...prev.subtasks, newSubtask]
    }));
  };

  const updateSubtask = (index: number, updates: Partial<Subtask>) => {
    setNewTask(prev => ({
      ...prev,
      subtasks: prev.subtasks.map((st, i) => 
        i === index ? { ...st, ...updates } : st
      )
    }));
  };

  const removeSubtask = (index: number) => {
    setNewTask(prev => ({
      ...prev,
      subtasks: prev.subtasks.filter((_, i) => i !== index)
    }));
  };

  const addTag = (tag: string) => {
    if (tag && !newTask.tags.includes(tag)) {
      setNewTask(prev => ({
        ...prev,
        tags: [...prev.tags, tag]
      }));
    }
  };

  const removeTag = (tagToRemove: string) => {
    setNewTask(prev => ({
      ...prev,
      tags: prev.tags.filter(tag => tag !== tagToRemove)
    }));
  };

  const toggleTaskExpansion = (taskId: number) => {
    setExpandedTasks(prev => {
      const newSet = new Set(prev);
      if (newSet.has(taskId)) {
        newSet.delete(taskId);
      } else {
        newSet.add(taskId);
      }
      return newSet;
    });
  };

  // Analytics calculations
  const getWeeklyStats = () => {
    const now = new Date();
    const weekAgo = new Date(now.getTime() - 7 * 24 * 60 * 60 * 1000);
    
    const weeklyTasks = tasks.filter(task => 
      new Date(task.createdAt) >= weekAgo
    );
    
    const completedThisWeek = weeklyTasks.filter(task => task.completed).length;
    const totalTimeSpent = weeklyTasks.reduce((sum, task) => sum + (task.actualTime || 0), 0);
    
    const categoryBreakdown = categories.map(cat => ({
      category: cat.value,
      count: weeklyTasks.filter(task => task.category === cat.value).length,
      color: cat.pastel
    })).filter(item => item.count > 0);

    return {
      totalTasks: weeklyTasks.length,
      completedTasks: completedThisWeek,
      completionRate: weeklyTasks.length > 0 ? (completedThisWeek / weeklyTasks.length) * 100 : 0,
      totalTimeSpent: Math.round(totalTimeSpent / 60), // Convert to hours
      categoryBreakdown
    };
  };

  const getMonthlyStats = () => {
    const now = new Date();
    const monthAgo = new Date(now.getTime() - 30 * 24 * 60 * 60 * 1000);
    
    const monthlyTasks = tasks.filter(task => 
      new Date(task.createdAt) >= monthAgo
    );
    
    const completedThisMonth = monthlyTasks.filter(task => task.completed).length;
    const averageTaskTime = monthlyTasks.length > 0 ? 
      monthlyTasks.reduce((sum, task) => sum + (task.estimatedTime || 0), 0) / monthlyTasks.length : 0;

    return {
      totalTasks: monthlyTasks.length,
      completedTasks: completedThisMonth,
      completionRate: monthlyTasks.length > 0 ? (completedThisMonth / monthlyTasks.length) * 100 : 0,
      averageTaskTime: Math.round(averageTaskTime)
    };
  };

  // Filter and sort tasks
  const filteredTasks = tasks
    .filter(task => {
      if (filterCategory !== "Tất cả" && task.category !== filterCategory) return false;
      if (filterPriority !== "Tất cả" && task.priority !== filterPriority) return false;
      return true;
    })
    .sort((a, b) => {
      switch (sortBy) {
        case "priority":
          const priorityOrder = { "Cao": 3, "Trung bình": 2, "Thấp": 1 };
          return (priorityOrder[b.priority as keyof typeof priorityOrder] || 0) - 
                 (priorityOrder[a.priority as keyof typeof priorityOrder] || 0);
        case "dueDate":
          if (!a.dueDate && !b.dueDate) return 0;
          if (!a.dueDate) return 1;
          if (!b.dueDate) return -1;
          return new Date(a.dueDate).getTime() - new Date(b.dueDate).getTime();
        case "created":
        default:
          return new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime();
      }
    });

  const completedTasks = filteredTasks.filter(task => task.completed).length;
  const totalTasks = filteredTasks.length;
  const progressPercentage = totalTasks > 0 ? (completedTasks / totalTasks) * 100 : 0;

  const getCategoryConfig = (category: string) => {
    return categories.find(c => c.value === category) || categories[categories.length - 1];
  };

  const getPriorityConfig = (priority: string) => {
    return priorities.find(p => p.value === priority) || priorities[1];
  };

  const formatDueDate = (date: Date | string | null) => {
    if (!date) return null;
    const dueDate = new Date(date);
    const now = new Date();
    const diffTime = dueDate.getTime() - now.getTime();
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
    
    if (diffDays < 0) return "Quá hạn";
    if (diffDays === 0) return "Hôm nay";
    if (diffDays === 1) return "Ngày mai";
    return `${diffDays} ngày nữa`;
  };

  const weeklyStats = getWeeklyStats();
  const monthlyStats = getMonthlyStats();

  if (isLoading) {
    return (
      <div className="pastel-card rounded-2xl shadow-sm overflow-hidden" style={{ animation: 'floatCard 6s ease-in-out infinite' }}>
        <div className="p-6">
          <div className="animate-pulse space-y-4">
            <div className="h-4 bg-gray-200 rounded w-3/4"></div>
            <div className="h-4 bg-gray-200 rounded w-1/2"></div>
            <div className="h-16 bg-gray-200 rounded"></div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Analytics Dashboard */}
      {showAnalytics && (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
          <Card className="pastel-card" style={{ background: 'var(--pastel-blue)' }}>
            <CardContent className="p-4">
              <div className="flex items-center">
                <TrendingUp className="text-blue-700" size={24} />
                <div className="ml-3">
                  <p className="text-sm text-blue-700">Tuần này</p>
                  <p className="text-2xl font-bold text-blue-800">{weeklyStats.completedTasks}/{weeklyStats.totalTasks}</p>
                  <p className="text-xs text-blue-600">{weeklyStats.completionRate.toFixed(0)}% hoàn thành</p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="pastel-card" style={{ background: 'var(--pastel-green)' }}>
            <CardContent className="p-4">
              <div className="flex items-center">
                <Clock className="text-green-700" size={24} />
                <div className="ml-3">
                  <p className="text-sm text-green-700">Thời gian học</p>
                  <p className="text-2xl font-bold text-green-800">{weeklyStats.totalTimeSpent}h</p>
                  <p className="text-xs text-green-600">Trong tuần</p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="pastel-card" style={{ background: 'var(--pastel-purple)' }}>
            <CardContent className="p-4">
              <div className="flex items-center">
                <Target className="text-purple-700" size={24} />
                <div className="ml-3">
                  <p className="text-sm text-purple-700">Tháng này</p>
                  <p className="text-2xl font-bold text-purple-800">{monthlyStats.completedTasks}/{monthlyStats.totalTasks}</p>
                  <p className="text-xs text-purple-600">{monthlyStats.completionRate.toFixed(0)}% hoàn thành</p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="pastel-card" style={{ background: 'var(--pastel-pink)' }}>
            <CardContent className="p-4">
              <div className="flex items-center">
                <Award className="text-pink-700" size={24} />
                <div className="ml-3">
                  <p className="text-sm text-pink-700">TB thời gian</p>
                  <p className="text-2xl font-bold text-pink-800">{monthlyStats.averageTaskTime}p</p>
                  <p className="text-xs text-pink-600">Mỗi nhiệm vụ</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      )}

      {/* Main Task Management */}
      <div className="pastel-card rounded-2xl shadow-sm overflow-hidden" style={{ animation: 'floatCard 6s ease-in-out infinite' }}>
        {/* Enhanced Header */}
        <div className="pastel-blue-gradient px-6 py-5 text-white">
          <div className="flex items-center justify-between">
            <div>
              <h2 className="text-xl font-semibold">Quản lý công việc IELTS</h2>
              <p className="text-blue-100 text-sm mt-1">{currentDate}</p>
            </div>
            <div className="flex items-center gap-3">
              <Button
                onClick={() => setShowAnalytics(!showAnalytics)}
                variant="outline"
                size="sm"
                className="bg-white/20 border-white/20 text-white hover:bg-white/30"
              >
                <BarChart3 size={16} className="mr-2" />
                {showAnalytics ? 'Ẩn' : 'Hiện'} thống kê
              </Button>
              <div className="bg-white/20 rounded-lg px-3 py-2">
                <Calendar size={20} />
              </div>
            </div>
          </div>
        </div>
        
        {/* Enhanced Progress Section */}
        <div className="px-6 py-4" style={{ background: 'var(--pastel-blue)' }}>
          <div className="flex items-center justify-between mb-2">
            <span className="text-sm font-medium text-blue-800">Tiến độ hôm nay</span>
            <span className="text-sm text-blue-700">{completedTasks}/{totalTasks} công việc</span>
          </div>
          <Progress value={progressPercentage} className="h-3 mb-2" />
          <div className="flex justify-between text-xs text-blue-600">
            <span>Hoàn thành: {progressPercentage.toFixed(0)}%</span>
            <span>Còn lại: {totalTasks - completedTasks}</span>
          </div>
        </div>

        {/* Filters and Actions */}
        <div className="px-6 py-4 border-b border-gray-100">
          <div className="flex flex-wrap gap-3 mb-4">
            <Select value={filterCategory} onValueChange={setFilterCategory}>
              <SelectTrigger className="w-44">
                <SelectValue placeholder="Danh mục" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="Tất cả">Tất cả danh mục</SelectItem>
                {categories.map(cat => (
                  <SelectItem key={cat.value} value={cat.value}>{cat.value}</SelectItem>
                ))}
              </SelectContent>
            </Select>

            <Select value={filterPriority} onValueChange={setFilterPriority}>
              <SelectTrigger className="w-36">
                <SelectValue placeholder="Ưu tiên" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="Tất cả">Tất cả ưu tiên</SelectItem>
                {priorities.map(p => (
                  <SelectItem key={p.value} value={p.value}>{p.value}</SelectItem>
                ))}
              </SelectContent>
            </Select>

            <Select value={sortBy} onValueChange={setSortBy}>
              <SelectTrigger className="w-36">
                <SelectValue placeholder="Sắp xếp" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="created">Mới nhất</SelectItem>
                <SelectItem value="priority">Ưu tiên</SelectItem>
                <SelectItem value="dueDate">Hạn chót</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div className="flex flex-wrap gap-3">
            <Button
              onClick={() => setIsAddingTask(true)}
              className="pastel-purple-gradient text-purple-800 hover:opacity-90 border-0"
            >
              <Plus size={16} className="mr-2" />
              Thêm nhiệm vụ IELTS
            </Button>
            <input 
              type="file" 
              id="imageUpload" 
              accept="image/*" 
              className="hidden" 
              onChange={handleImageUpload}
            />
            <Button
              variant="outline"
              onClick={() => document.getElementById('imageUpload')?.click()}
              className="pastel-green-gradient text-green-800 border-0"
            >
              <Paperclip size={16} className="mr-2" />
              Đính kèm hình ảnh
            </Button>
          </div>
        </div>
        
        {/* Enhanced Add Task Form */}
        {isAddingTask && (
          <div className="px-6 py-6 animate-slide-in" style={{ background: 'var(--pastel-mint)' }}>
            <div className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <label className="text-sm font-medium text-gray-700">Tên nhiệm vụ *</label>
                  <Input
                    placeholder="VD: Luyện tập Listening Part 1..."
                    value={newTask.title}
                    onChange={(e) => setNewTask(prev => ({ ...prev, title: e.target.value }))}
                    className="bg-white/80 backdrop-blur-sm"
                  />
                </div>
                <div className="space-y-2">
                  <label className="text-sm font-medium text-gray-700">Kỹ năng IELTS</label>
                  <Select value={newTask.category} onValueChange={(value) => setNewTask(prev => ({ ...prev, category: value }))}>
                    <SelectTrigger className="bg-white/80 backdrop-blur-sm">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {categories.map(cat => (
                        <SelectItem key={cat.value} value={cat.value}>{cat.value}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div className="space-y-2">
                <label className="text-sm font-medium text-gray-700">Mô tả chi tiết</label>
                <Textarea
                  placeholder="Mô tả chi tiết về nhiệm vụ học IELTS..."
                  value={newTask.description}
                  onChange={(e) => setNewTask(prev => ({ ...prev, description: e.target.value }))}
                  className="bg-white/80 backdrop-blur-sm"
                  rows={3}
                />
              </div>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div className="space-y-2">
                  <label className="text-sm font-medium text-gray-700">Ưu tiên</label>
                  <Select value={newTask.priority} onValueChange={(value) => setNewTask(prev => ({ ...prev, priority: value }))}>
                    <SelectTrigger className="bg-white/80 backdrop-blur-sm">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {priorities.map(p => (
                        <SelectItem key={p.value} value={p.value}>{p.value}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <label className="text-sm font-medium text-gray-700">Thời gian ước tính (phút)</label>
                  <Input
                    type="number"
                    value={newTask.estimatedTime}
                    onChange={(e) => setNewTask(prev => ({ ...prev, estimatedTime: parseInt(e.target.value) || 30 }))}
                    className="bg-white/80 backdrop-blur-sm"
                  />
                </div>
                <div className="space-y-2">
                  <label className="text-sm font-medium text-gray-700">Hạn chót</label>
                  <Input
                    type="datetime-local"
                    value={newTask.dueDate}
                    onChange={(e) => setNewTask(prev => ({ ...prev, dueDate: e.target.value }))}
                    className="bg-white/80 backdrop-blur-sm"
                  />
                </div>
              </div>

              {/* Tags */}
              <div className="space-y-2">
                <label className="text-sm font-medium text-gray-700">Thẻ tag</label>
                <div className="flex flex-wrap gap-2 mb-2">
                  {newTask.tags.map(tag => (
                    <Badge 
                      key={tag} 
                      variant="secondary" 
                      className="cursor-pointer hover:bg-red-100" 
                      onClick={() => removeTag(tag)}
                    >
                      {tag} ×
                    </Badge>
                  ))}
                </div>
                <Input
                  placeholder="Nhập tag và nhấn Enter..."
                  onKeyPress={(e) => {
                    if (e.key === 'Enter') {
                      e.preventDefault();
                      addTag(e.currentTarget.value);
                      e.currentTarget.value = '';
                    }
                  }}
                  className="bg-white/80 backdrop-blur-sm"
                />
              </div>

              {/* Subtasks */}
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <label className="text-sm font-medium text-gray-700">Nhiệm vụ con</label>
                  <Button type="button" onClick={addSubtask} variant="outline" size="sm">
                    <Plus size={14} className="mr-1" />
                    Thêm
                  </Button>
                </div>
                <div className="space-y-2">
                  {newTask.subtasks.map((subtask, index) => (
                    <div key={subtask.id} className="flex gap-2 items-center">
                      <Input
                        placeholder="Tên nhiệm vụ con..."
                        value={subtask.title}
                        onChange={(e) => updateSubtask(index, { title: e.target.value })}
                        className="bg-white/80 backdrop-blur-sm flex-1"
                      />
                      <Button 
                        type="button" 
                        onClick={() => removeSubtask(index)}
                        variant="outline" 
                        size="sm"
                        className="text-red-600 hover:text-red-700"
                      >
                        <Trash2 size={14} />
                      </Button>
                    </div>
                  ))}
                </div>
              </div>

              <div className="flex gap-3 pt-2">
                <Button
                  onClick={handleAddTask}
                  disabled={createTaskMutation.isPending || !newTask.title.trim()}
                  className="pastel-purple-gradient text-purple-800"
                >
                  {createTaskMutation.isPending ? 'Đang thêm...' : 'Thêm nhiệm vụ'}
                </Button>
                <Button
                  variant="outline"
                  onClick={() => {
                    setIsAddingTask(false);
                    resetForm();
                  }}
                >
                  Hủy
                </Button>
              </div>
            </div>
          </div>
        )}
        
        {/* Enhanced Task List */}
        <div className="px-6 py-4">
          {filteredTasks.length === 0 ? (
            <div className="text-center py-12">
              <div className="w-16 h-16 mx-auto rounded-full flex items-center justify-center mb-4" style={{ background: 'var(--pastel-purple)' }}>
                <ListTodo className="text-purple-700" size={24} />
              </div>
              <p className="text-gray-500">
                {filterCategory !== "Tất cả" || filterPriority !== "Tất cả" 
                  ? "Không có nhiệm vụ nào phù hợp với bộ lọc"
                  : "Chưa có nhiệm vụ nào. Hãy thêm nhiệm vụ IELTS đầu tiên!"
                }
              </p>
            </div>
          ) : (
            <div className="space-y-3">
              {filteredTasks.map((task) => {
                const isExpanded = expandedTasks.has(task.id);
                const categoryConfig = getCategoryConfig(task.category);
                const priorityConfig = getPriorityConfig(task.priority);
                const dueDateInfo = formatDueDate(task.dueDate);
                const hasDetails = task.description || (task.tags && task.tags.length > 0) || 
                                 (task.subtasks && Array.isArray(task.subtasks) && task.subtasks.length > 0) ||
                                 (task.attachments && Array.isArray(task.attachments) && task.attachments.length > 0) ||
                                 (task.results && Array.isArray(task.results) && task.results.length > 0);

                return (
                  <div
                    key={task.id}
                    className="pastel-card rounded-xl overflow-hidden animate-slide-in"
                    style={{ 
                      background: `linear-gradient(135deg, ${categoryConfig.pastel}40, white)`,
                      animation: 'floatCard 6s ease-in-out infinite',
                      animationDelay: `${task.id * 0.1}s`
                    }}
                  >
                    {/* Main Task Row */}
                    <div className="p-4 flex items-center space-x-4">
                      <Checkbox
                        checked={task.completed}
                        onCheckedChange={(checked) => handleToggleTask(task.id, checked as boolean)}
                        className="w-5 h-5"
                      />
                      
                      <div className="flex-1">
                        <div className="flex items-center gap-2 mb-1">
                          <h4 className={`font-medium text-gray-900 ${task.completed ? 'line-through opacity-60' : ''}`}>
                            {task.title}
                          </h4>
                          <Badge 
                            className="border-0 text-white" 
                            style={{ background: priorityConfig.pastel }}
                          >
                            {task.priority}
                          </Badge>
                          {task.category && task.category !== "Khác" && (
                            <Badge 
                              variant="secondary" 
                              className="text-xs border-0"
                              style={{ background: categoryConfig.pastel, color: 'white' }}
                            >
                              {task.category}
                            </Badge>
                          )}
                        </div>
                        
                        <div className="flex items-center gap-4 text-sm text-gray-500">
                          <span className="flex items-center gap-1">
                            <Clock size={14} />
                            {task.estimatedTime} phút
                          </span>
                          {dueDateInfo && (
                            <span className={`flex items-center gap-1 ${
                              dueDateInfo === "Quá hạn" ? "text-red-600" : 
                              dueDateInfo === "Hôm nay" ? "text-orange-600" : ""
                            }`}>
                              <CalendarDays size={14} />
                              {dueDateInfo}
                            </span>
                          )}
                          {task.completedAt && (
                            <span className="flex items-center gap-1 text-green-600">
                              <CheckCircle2 size={14} />
                              Hoàn thành {new Date(task.completedAt).toLocaleDateString('vi-VN')}
                            </span>
                          )}
                        </div>
                      </div>

                      <div className="flex items-center space-x-2">
                        {hasDetails && (
                          <Button
                            onClick={() => toggleTaskExpansion(task.id)}
                            variant="ghost"
                            size="sm"
                            className="text-gray-400 hover:text-gray-600"
                          >
                            {isExpanded ? <ChevronDown size={16} /> : <ChevronRight size={16} />}
                          </Button>
                        )}
                        <Button
                          onClick={() => handleDeleteTask(task.id)}
                          variant="ghost"
                          size="sm"
                          className="text-gray-400 hover:text-red-500"
                          disabled={deleteTaskMutation.isPending}
                        >
                          <Trash2 size={16} />
                        </Button>
                      </div>
                    </div>

                    {/* Expanded Details */}
                    {isExpanded && hasDetails && (
                      <div className="px-4 pb-4 border-t border-white/50 bg-white/30 animate-fade-in">
                        {task.description && (
                          <div className="mb-3 mt-3">
                            <h5 className="text-sm font-medium text-gray-700 mb-1">Mô tả:</h5>
                            <p className="text-sm text-gray-600">{task.description}</p>
                          </div>
                        )}

                        {task.tags && task.tags.length > 0 && (
                          <div className="mb-3">
                            <h5 className="text-sm font-medium text-gray-700 mb-1">Tags:</h5>
                            <div className="flex flex-wrap gap-1">
                              {task.tags.map(tag => (
                                <Badge key={tag} variant="outline" className="text-xs">
                                  <Tag size={10} className="mr-1" />
                                  {tag}
                                </Badge>
                              ))}
                            </div>
                          </div>
                        )}

                        {task.subtasks && Array.isArray(task.subtasks) && task.subtasks.length > 0 && (
                          <div className="mb-3">
                            <h5 className="text-sm font-medium text-gray-700 mb-2">Nhiệm vụ con:</h5>
                            <div className="space-y-1">
                              {task.subtasks.map((subtask: any, index: number) => (
                                <div key={index} className="flex items-center gap-2 text-sm">
                                  <Circle size={12} className="text-gray-400" />
                                  <span className={subtask.completed ? 'line-through text-gray-500' : 'text-gray-700'}>
                                    {typeof subtask === 'string' ? subtask : subtask.title}
                                  </span>
                                </div>
                              ))}
                            </div>
                          </div>
                        )}

                        {task.attachments && Array.isArray(task.attachments) && task.attachments.length > 0 && (
                          <div className="mb-3">
                            <h5 className="text-sm font-medium text-gray-700 mb-2">Tệp đính kèm:</h5>
                            <div className="flex flex-wrap gap-2">
                              {task.attachments.map((attachment: any, index: number) => (
                                <div key={index} className="flex items-center gap-2 p-2 bg-white/50 rounded-lg">
                                  <Image size={16} className="text-gray-500" />
                                  <span className="text-xs text-gray-600">{attachment.name}</span>
                                </div>
                              ))}
                            </div>
                          </div>
                        )}

                        {task.results && Array.isArray(task.results) && task.results.length > 0 && (
                          <div>
                            <h5 className="text-sm font-medium text-gray-700 mb-2">Kết quả:</h5>
                            <div className="space-y-2">
                              {task.results.map((result: any, index: number) => (
                                <div key={index} className="p-2 bg-white/50 rounded-lg">
                                  <div className="flex items-center gap-2 mb-1">
                                    {result.type === 'image' && <Camera size={14} className="text-gray-500" />}
                                    {result.type === 'score' && <Award size={14} className="text-green-500" />}
                                    {result.type === 'text' && <FileText size={14} className="text-blue-500" />}
                                    <span className="text-xs text-gray-600">{result.description}</span>
                                  </div>
                                  <p className="text-sm text-gray-700">{result.content}</p>
                                </div>
                              ))}
                            </div>
                          </div>
                        )}
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}