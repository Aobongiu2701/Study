import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { 
  Plus, Paperclip, Download, Trash2, Calendar, ListTodo, Clock, 
  Tag, FileText, ChevronDown, ChevronRight, CheckCircle2, 
  Circle, AlertCircle, CalendarDays, Timer
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Checkbox } from "@/components/ui/checkbox";
import { useToast } from "@/hooks/use-toast";
import type { Task, InsertTask } from "@shared/schema";

interface TaskManagementProps {
  currentDate: string;
}

interface Subtask {
  id: string;
  title: string;
  completed: boolean;
}

const categories = [
  "IELTS Học tập", "Từ vựng", "Ngữ pháp", "Luyện thi", 
  "Công việc", "Cá nhân", "Sức khỏe", "Khác"
];

const priorities = [
  { value: "Cao", color: "bg-red-100 text-red-700 border-red-200" },
  { value: "Trung bình", color: "bg-yellow-100 text-yellow-700 border-yellow-200" },
  { value: "Thấp", color: "bg-green-100 text-green-700 border-green-200" }
];

export default function TaskManagementEnhanced({ currentDate }: TaskManagementProps) {
  const [isAddingTask, setIsAddingTask] = useState(false);
  const [expandedTasks, setExpandedTasks] = useState<Set<number>>(new Set());
  const [filterCategory, setFilterCategory] = useState<string>("Tất cả");
  const [filterPriority, setFilterPriority] = useState<string>("Tất cả");
  const [sortBy, setSortBy] = useState<string>("created");

  // Form state
  const [newTask, setNewTask] = useState({
    title: "",
    description: "",
    priority: "Trung bình",
    category: "Khác",
    estimatedTime: 30,
    dueDate: "",
    tags: [] as string[],
    subtasks: [] as Subtask[]
  });

  const { toast } = useToast();

  const { data: tasks = [], isLoading } = useQuery<Task[]>({
    queryKey: ['/api/tasks'],
  });

  const createTaskMutation = useMutation({
    mutationFn: async (task: InsertTask) => {
      const response = await apiRequest('POST', '/api/tasks', task);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/tasks'] });
      setIsAddingTask(false);
      resetForm();
      toast({
        title: "Thành công",
        description: "Đã thêm công việc mới với chi tiết đầy đủ",
      });
    },
  });

  const updateTaskMutation = useMutation({
    mutationFn: async ({ id, updates }: { id: number; updates: Partial<Task> }) => {
      const response = await apiRequest('PATCH', `/api/tasks/${id}`, updates);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/tasks'] });
    },
  });

  const deleteTaskMutation = useMutation({
    mutationFn: async (id: number) => {
      const response = await apiRequest('DELETE', `/api/tasks/${id}`);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/tasks'] });
      toast({
        title: "Đã xóa",
        description: "Công việc đã được xóa",
      });
    },
  });

  const resetForm = () => {
    setNewTask({
      title: "",
      description: "",
      priority: "Trung bình",
      category: "Khác",
      estimatedTime: 30,
      dueDate: "",
      tags: [],
      subtasks: []
    });
  };

  const handleAddTask = () => {
    if (!newTask.title.trim()) return;
    
    createTaskMutation.mutate({
      title: newTask.title,
      description: newTask.description || null,
      priority: newTask.priority,
      category: newTask.category,
      estimatedTime: newTask.estimatedTime,
      dueDate: newTask.dueDate ? new Date(newTask.dueDate) : null,
      tags: newTask.tags,
      subtasks: newTask.subtasks,
      completed: false,
    });
  };

  const handleToggleTask = (taskId: number, completed: boolean) => {
    updateTaskMutation.mutate({
      id: taskId,
      updates: { completed }
    });
  };

  const handleDeleteTask = (taskId: number) => {
    if (confirm('Bạn có chắc muốn xóa công việc này?')) {
      deleteTaskMutation.mutate(taskId);
    }
  };

  const addSubtask = () => {
    const newSubtask: Subtask = {
      id: Date.now().toString(),
      title: "",
      completed: false
    };
    setNewTask(prev => ({
      ...prev,
      subtasks: [...prev.subtasks, newSubtask]
    }));
  };

  const updateSubtask = (index: number, updates: Partial<Subtask>) => {
    setNewTask(prev => ({
      ...prev,
      subtasks: prev.subtasks.map((st, i) => 
        i === index ? { ...st, ...updates } : st
      )
    }));
  };

  const removeSubtask = (index: number) => {
    setNewTask(prev => ({
      ...prev,
      subtasks: prev.subtasks.filter((_, i) => i !== index)
    }));
  };

  const addTag = (tag: string) => {
    if (tag && !newTask.tags.includes(tag)) {
      setNewTask(prev => ({
        ...prev,
        tags: [...prev.tags, tag]
      }));
    }
  };

  const removeTag = (tagToRemove: string) => {
    setNewTask(prev => ({
      ...prev,
      tags: prev.tags.filter(tag => tag !== tagToRemove)
    }));
  };

  const toggleTaskExpansion = (taskId: number) => {
    setExpandedTasks(prev => {
      const newSet = new Set(prev);
      if (newSet.has(taskId)) {
        newSet.delete(taskId);
      } else {
        newSet.add(taskId);
      }
      return newSet;
    });
  };

  // Filter and sort tasks
  const filteredTasks = tasks
    .filter(task => {
      if (filterCategory !== "Tất cả" && task.category !== filterCategory) return false;
      if (filterPriority !== "Tất cả" && task.priority !== filterPriority) return false;
      return true;
    })
    .sort((a, b) => {
      switch (sortBy) {
        case "priority":
          const priorityOrder = { "Cao": 3, "Trung bình": 2, "Thấp": 1 };
          return (priorityOrder[b.priority as keyof typeof priorityOrder] || 0) - 
                 (priorityOrder[a.priority as keyof typeof priorityOrder] || 0);
        case "dueDate":
          if (!a.dueDate && !b.dueDate) return 0;
          if (!a.dueDate) return 1;
          if (!b.dueDate) return -1;
          return new Date(a.dueDate).getTime() - new Date(b.dueDate).getTime();
        case "created":
        default:
          return new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime();
      }
    });

  const completedTasks = filteredTasks.filter(task => task.completed).length;
  const totalTasks = filteredTasks.length;
  const progressPercentage = totalTasks > 0 ? (completedTasks / totalTasks) * 100 : 0;

  const getPriorityConfig = (priority: string) => {
    return priorities.find(p => p.value === priority) || priorities[1];
  };

  const formatDueDate = (date: Date | string | null) => {
    if (!date) return null;
    const dueDate = new Date(date);
    const now = new Date();
    const diffTime = dueDate.getTime() - now.getTime();
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
    
    if (diffDays < 0) return "Quá hạn";
    if (diffDays === 0) return "Hôm nay";
    if (diffDays === 1) return "Ngày mai";
    return `${diffDays} ngày nữa`;
  };

  if (isLoading) {
    return (
      <div className="bg-white rounded-2xl shadow-sm border border-gray-100 overflow-hidden">
        <div className="p-6">
          <div className="animate-pulse space-y-4">
            <div className="h-4 bg-gray-200 rounded w-3/4"></div>
            <div className="h-4 bg-gray-200 rounded w-1/2"></div>
            <div className="h-16 bg-gray-200 rounded"></div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="bg-white rounded-2xl shadow-sm border border-gray-100 overflow-hidden">
      {/* Enhanced Header */}
      <div className="study-blue-gradient px-6 py-5 text-white">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-xl font-semibold">Quản lý công việc chi tiết</h2>
            <p className="text-blue-100 text-sm mt-1">{currentDate}</p>
          </div>
          <div className="bg-white/20 rounded-lg px-3 py-2">
            <Calendar size={20} />
          </div>
        </div>
      </div>
      
      {/* Enhanced Progress Section */}
      <div className="px-6 py-4 bg-gray-50 border-b border-gray-100">
        <div className="flex items-center justify-between mb-2">
          <span className="text-sm font-medium text-gray-700">Tiến độ hôm nay</span>
          <span className="text-sm text-gray-500">{completedTasks}/{totalTasks} công việc</span>
        </div>
        <div className="w-full bg-gray-200 rounded-full h-2">
          <div 
            className="progress-bar h-2 rounded-full" 
            style={{ width: `${progressPercentage}%` }}
          />
        </div>
        <div className="flex justify-between text-xs text-gray-500 mt-2">
          <span>Hoàn thành: {progressPercentage.toFixed(0)}%</span>
          <span>Còn lại: {totalTasks - completedTasks}</span>
        </div>
      </div>

      {/* Filters and Actions */}
      <div className="px-6 py-4 border-b border-gray-100">
        <div className="flex flex-wrap gap-3 mb-4">
          <Select value={filterCategory} onValueChange={setFilterCategory}>
            <SelectTrigger className="w-40">
              <SelectValue placeholder="Danh mục" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="Tất cả">Tất cả danh mục</SelectItem>
              {categories.map(cat => (
                <SelectItem key={cat} value={cat}>{cat}</SelectItem>
              ))}
            </SelectContent>
          </Select>

          <Select value={filterPriority} onValueChange={setFilterPriority}>
            <SelectTrigger className="w-36">
              <SelectValue placeholder="Ưu tiên" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="Tất cả">Tất cả ưu tiên</SelectItem>
              {priorities.map(p => (
                <SelectItem key={p.value} value={p.value}>{p.value}</SelectItem>
              ))}
            </SelectContent>
          </Select>

          <Select value={sortBy} onValueChange={setSortBy}>
            <SelectTrigger className="w-36">
              <SelectValue placeholder="Sắp xếp" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="created">Mới nhất</SelectItem>
              <SelectItem value="priority">Ưu tiên</SelectItem>
              <SelectItem value="dueDate">Hạn chót</SelectItem>
            </SelectContent>
          </Select>
        </div>

        <div className="flex flex-wrap gap-3">
          <Button
            onClick={() => setIsAddingTask(true)}
            className="study-blue-gradient text-white hover:opacity-90"
          >
            <Plus size={16} className="mr-2" />
            Thêm công việc chi tiết
          </Button>
          <Button
            variant="outline"
            className="bg-green-50 text-green-700 border-green-200 hover:bg-green-100"
          >
            <Paperclip size={16} className="mr-2" />
            Đính kèm
          </Button>
          <Button
            variant="outline"
            className="bg-gray-100 text-gray-700 hover:bg-gray-200"
          >
            <Download size={16} className="mr-2" />
            Xuất dữ liệu
          </Button>
        </div>
      </div>
      
      {/* Enhanced Add Task Form */}
      {isAddingTask && (
        <div className="px-6 py-6 bg-blue-50 border-b border-gray-100 animate-slide-in">
          <div className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <label className="text-sm font-medium text-gray-700">Tên công việc *</label>
                <Input
                  placeholder="Nhập tên công việc..."
                  value={newTask.title}
                  onChange={(e) => setNewTask(prev => ({ ...prev, title: e.target.value }))}
                  className="bg-white"
                />
              </div>
              <div className="space-y-2">
                <label className="text-sm font-medium text-gray-700">Danh mục</label>
                <Select value={newTask.category} onValueChange={(value) => setNewTask(prev => ({ ...prev, category: value }))}>
                  <SelectTrigger className="bg-white">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {categories.map(cat => (
                      <SelectItem key={cat} value={cat}>{cat}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>

            <div className="space-y-2">
              <label className="text-sm font-medium text-gray-700">Mô tả</label>
              <Textarea
                placeholder="Mô tả chi tiết công việc..."
                value={newTask.description}
                onChange={(e) => setNewTask(prev => ({ ...prev, description: e.target.value }))}
                className="bg-white"
                rows={3}
              />
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className="space-y-2">
                <label className="text-sm font-medium text-gray-700">Ưu tiên</label>
                <Select value={newTask.priority} onValueChange={(value) => setNewTask(prev => ({ ...prev, priority: value }))}>
                  <SelectTrigger className="bg-white">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {priorities.map(p => (
                      <SelectItem key={p.value} value={p.value}>{p.value}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <label className="text-sm font-medium text-gray-700">Thời gian ước tính (phút)</label>
                <Input
                  type="number"
                  value={newTask.estimatedTime}
                  onChange={(e) => setNewTask(prev => ({ ...prev, estimatedTime: parseInt(e.target.value) || 30 }))}
                  className="bg-white"
                />
              </div>
              <div className="space-y-2">
                <label className="text-sm font-medium text-gray-700">Hạn chót</label>
                <Input
                  type="datetime-local"
                  value={newTask.dueDate}
                  onChange={(e) => setNewTask(prev => ({ ...prev, dueDate: e.target.value }))}
                  className="bg-white"
                />
              </div>
            </div>

            {/* Tags */}
            <div className="space-y-2">
              <label className="text-sm font-medium text-gray-700">Thẻ tag</label>
              <div className="flex flex-wrap gap-2 mb-2">
                {newTask.tags.map(tag => (
                  <Badge key={tag} variant="secondary" className="cursor-pointer" onClick={() => removeTag(tag)}>
                    {tag} ×
                  </Badge>
                ))}
              </div>
              <Input
                placeholder="Nhập tag và nhấn Enter..."
                onKeyPress={(e) => {
                  if (e.key === 'Enter') {
                    e.preventDefault();
                    addTag(e.currentTarget.value);
                    e.currentTarget.value = '';
                  }
                }}
                className="bg-white"
              />
            </div>

            {/* Subtasks */}
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <label className="text-sm font-medium text-gray-700">Công việc con</label>
                <Button type="button" onClick={addSubtask} variant="outline" size="sm">
                  <Plus size={14} className="mr-1" />
                  Thêm
                </Button>
              </div>
              <div className="space-y-2">
                {newTask.subtasks.map((subtask, index) => (
                  <div key={subtask.id} className="flex gap-2 items-center">
                    <Input
                      placeholder="Tên công việc con..."
                      value={subtask.title}
                      onChange={(e) => updateSubtask(index, { title: e.target.value })}
                      className="bg-white flex-1"
                    />
                    <Button 
                      type="button" 
                      onClick={() => removeSubtask(index)}
                      variant="outline" 
                      size="sm"
                      className="text-red-600 hover:text-red-700"
                    >
                      <Trash2 size={14} />
                    </Button>
                  </div>
                ))}
              </div>
            </div>

            <div className="flex gap-3 pt-2">
              <Button
                onClick={handleAddTask}
                disabled={createTaskMutation.isPending || !newTask.title.trim()}
                className="study-blue-gradient text-white"
              >
                {createTaskMutation.isPending ? 'Đang thêm...' : 'Thêm công việc'}
              </Button>
              <Button
                variant="outline"
                onClick={() => {
                  setIsAddingTask(false);
                  resetForm();
                }}
              >
                Hủy
              </Button>
            </div>
          </div>
        </div>
      )}
      
      {/* Enhanced Task List */}
      <div className="px-6 py-4">
        {filteredTasks.length === 0 ? (
          <div className="text-center py-12">
            <div className="w-16 h-16 mx-auto bg-gray-100 rounded-full flex items-center justify-center mb-4">
              <ListTodo className="text-gray-400" size={24} />
            </div>
            <p className="text-gray-500">
              {filterCategory !== "Tất cả" || filterPriority !== "Tất cả" 
                ? "Không có công việc nào phù hợp với bộ lọc"
                : "Chưa có công việc nào. Hãy thêm công việc đầu tiên!"
              }
            </p>
          </div>
        ) : (
          <div className="space-y-3">
            {filteredTasks.map((task) => {
              const isExpanded = expandedTasks.has(task.id);
              const priorityConfig = getPriorityConfig(task.priority);
              const dueDateInfo = formatDueDate(task.dueDate);
              const hasDetails = task.description || (task.tags && task.tags.length > 0) || 
                               (task.subtasks && Array.isArray(task.subtasks) && task.subtasks.length > 0);

              return (
                <div
                  key={task.id}
                  className="task-item bg-gray-50 rounded-xl border border-gray-100 animate-slide-in overflow-hidden"
                >
                  {/* Main Task Row */}
                  <div className="p-4 flex items-center space-x-4">
                    <Checkbox
                      checked={task.completed}
                      onCheckedChange={(checked) => handleToggleTask(task.id, checked as boolean)}
                      className="w-5 h-5"
                    />
                    
                    <div className="flex-1">
                      <div className="flex items-center gap-2 mb-1">
                        <h4 className={`font-medium text-gray-900 ${task.completed ? 'line-through opacity-60' : ''}`}>
                          {task.title}
                        </h4>
                        <Badge className={priorityConfig.color} variant="outline">
                          {task.priority}
                        </Badge>
                        {task.category && task.category !== "Khác" && (
                          <Badge variant="secondary" className="text-xs">
                            {task.category}
                          </Badge>
                        )}
                      </div>
                      
                      <div className="flex items-center gap-4 text-sm text-gray-500">
                        <span className="flex items-center gap-1">
                          <Clock size={14} />
                          {task.estimatedTime} phút
                        </span>
                        {dueDateInfo && (
                          <span className={`flex items-center gap-1 ${
                            dueDateInfo === "Quá hạn" ? "text-red-600" : 
                            dueDateInfo === "Hôm nay" ? "text-orange-600" : ""
                          }`}>
                            <CalendarDays size={14} />
                            {dueDateInfo}
                          </span>
                        )}
                        {task.completedAt && (
                          <span className="flex items-center gap-1 text-green-600">
                            <CheckCircle2 size={14} />
                            Hoàn thành {new Date(task.completedAt).toLocaleDateString('vi-VN')}
                          </span>
                        )}
                      </div>
                    </div>

                    <div className="flex items-center space-x-2">
                      {hasDetails && (
                        <Button
                          onClick={() => toggleTaskExpansion(task.id)}
                          variant="ghost"
                          size="sm"
                          className="text-gray-400 hover:text-gray-600"
                        >
                          {isExpanded ? <ChevronDown size={16} /> : <ChevronRight size={16} />}
                        </Button>
                      )}
                      <Button
                        onClick={() => handleDeleteTask(task.id)}
                        variant="ghost"
                        size="sm"
                        className="text-gray-400 hover:text-red-500"
                        disabled={deleteTaskMutation.isPending}
                      >
                        <Trash2 size={16} />
                      </Button>
                    </div>
                  </div>

                  {/* Expanded Details */}
                  {isExpanded && hasDetails && (
                    <div className="px-4 pb-4 border-t border-gray-200 bg-white/50 animate-fade-in">
                      {task.description && (
                        <div className="mb-3">
                          <h5 className="text-sm font-medium text-gray-700 mb-1">Mô tả:</h5>
                          <p className="text-sm text-gray-600">{task.description}</p>
                        </div>
                      )}

                      {task.tags && task.tags.length > 0 && (
                        <div className="mb-3">
                          <h5 className="text-sm font-medium text-gray-700 mb-1">Tags:</h5>
                          <div className="flex flex-wrap gap-1">
                            {task.tags.map(tag => (
                              <Badge key={tag} variant="outline" className="text-xs">
                                <Tag size={10} className="mr-1" />
                                {tag}
                              </Badge>
                            ))}
                          </div>
                        </div>
                      )}

                      {task.subtasks && Array.isArray(task.subtasks) && task.subtasks.length > 0 && (
                        <div>
                          <h5 className="text-sm font-medium text-gray-700 mb-2">Công việc con:</h5>
                          <div className="space-y-1">
                            {task.subtasks.map((subtask: any, index: number) => (
                              <div key={index} className="flex items-center gap-2 text-sm">
                                <Circle size={12} className="text-gray-400" />
                                <span className={subtask.completed ? 'line-through text-gray-500' : 'text-gray-700'}>
                                  {subtask.title}
                                </span>
                              </div>
                            ))}
                          </div>
                        </div>
                      )}
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
}