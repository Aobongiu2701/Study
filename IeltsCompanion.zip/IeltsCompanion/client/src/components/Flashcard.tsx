import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { RotateCcw, Shuffle } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useToast } from "@/hooks/use-toast";
import type { Flashcard as FlashcardType } from "@shared/schema";

export default function Flashcard() {
  const [isFlipped, setIsFlipped] = useState(false);
  const { toast } = useToast();

  const { data: currentFlashcard, refetch } = useQuery<FlashcardType>({
    queryKey: ['/api/flashcards/next'],
  });

  const { data: allFlashcards = [] } = useQuery<FlashcardType[]>({
    queryKey: ['/api/flashcards'],
  });

  const updateFlashcardMutation = useMutation({
    mutationFn: async ({ id, updates }: { id: number; updates: Partial<FlashcardType> }) => {
      const response = await apiRequest('PATCH', `/api/flashcards/${id}`, updates);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/flashcards'] });
      refetch();
      setIsFlipped(false);
    },
  });

  const handleFlip = () => {
    setIsFlipped(!isFlipped);
  };

  const handleSRSResponse = (difficulty: 'easy' | 'hard') => {
    if (!currentFlashcard) return;

    const now = new Date();
    const daysToAdd = difficulty === 'easy' ? 3 : 1;
    const nextReview = new Date(now.getTime() + daysToAdd * 24 * 60 * 60 * 1000);

    updateFlashcardMutation.mutate({
      id: currentFlashcard.id,
      updates: {
        nextReview,
        reviewCount: currentFlashcard.reviewCount + 1,
        difficulty: difficulty === 'easy' ? Math.max(1, currentFlashcard.difficulty - 1) : Math.min(5, currentFlashcard.difficulty + 1)
      }
    });

    const message = difficulty === 'easy' 
      ? 'Tuyệt vời! Hẹn gặp lại sau 3 ngày' 
      : 'Không sao, sẽ ôn lại sớm hơn!';
    
    toast({
      title: "Đã lưu",
      description: message,
    });
  };

  const shuffleFlashcard = () => {
    refetch();
    setIsFlipped(false);
  };

  if (!currentFlashcard) {
    return (
      <div className="bg-white rounded-2xl shadow-sm border border-gray-100 overflow-hidden">
        <div className="px-6 py-4 border-b border-gray-100">
          <h3 className="text-lg font-semibold text-gray-900">Flashcard</h3>
        </div>
        <div className="p-6">
          <div className="h-64 bg-gray-100 rounded-xl flex items-center justify-center">
            <p className="text-gray-500">Không có flashcard nào</p>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="bg-white rounded-2xl shadow-sm border border-gray-100 overflow-hidden">
      <div className="px-6 py-4 border-b border-gray-100">
        <div className="flex items-center justify-between">
          <h3 className="text-lg font-semibold text-gray-900">Flashcard</h3>
          <div className="flex items-center space-x-2">
            <span className="text-sm text-gray-500">
              {currentFlashcard.reviewCount} lần ôn tập
            </span>
            <Button
              onClick={shuffleFlashcard}
              variant="ghost"
              size="sm"
              className="text-gray-400 hover:text-gray-600"
            >
              <Shuffle size={16} />
            </Button>
          </div>
        </div>
      </div>
      
      <div className="p-6">
        <div className="relative h-64">
          <div 
            className={`flashcard-flip w-full h-full cursor-pointer ${isFlipped ? 'flipped' : ''}`}
            onClick={handleFlip}
          >
            {/* Front */}
            <div className="flashcard-front bg-gradient-to-br from-pink-100 to-pink-200 rounded-xl p-6 flex flex-col justify-center items-center hover:shadow-lg transition-shadow">
              <div className="text-center">
                <h4 className="text-2xl font-bold text-gray-800 mb-2">
                  {currentFlashcard.word}
                </h4>
                <p className="text-gray-600 text-sm mb-4">(từ vựng)</p>
                <div className="text-gray-500">
                  <RotateCcw size={20} className="mx-auto mb-2" />
                  <p className="text-xs">Nhấp để xem nghĩa</p>
                </div>
              </div>
            </div>
            
            {/* Back */}
            <div className="flashcard-back bg-gradient-to-br from-blue-100 to-blue-200 rounded-xl p-6 flex flex-col justify-center">
              <div className="text-center">
                <h4 className="text-xl font-semibold text-gray-800 mb-3">
                  {currentFlashcard.meaning}
                </h4>
                {currentFlashcard.example && (
                  <p className="text-gray-600 text-sm mb-4 italic">
                    "{currentFlashcard.example}"
                  </p>
                )}
                
                <div className="flex justify-center space-x-3">
                  <Button
                    onClick={(e) => {
                      e.stopPropagation();
                      handleSRSResponse('easy');
                    }}
                    disabled={updateFlashcardMutation.isPending}
                    className="bg-green-100 text-green-700 hover:bg-green-200 border-green-200"
                    variant="outline"
                  >
                    ✓ Dễ
                  </Button>
                  <Button
                    onClick={(e) => {
                      e.stopPropagation();
                      handleSRSResponse('hard');
                    }}
                    disabled={updateFlashcardMutation.isPending}
                    className="bg-red-100 text-red-700 hover:bg-red-200 border-red-200"
                    variant="outline"
                  >
                    ✗ Khó
                  </Button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
