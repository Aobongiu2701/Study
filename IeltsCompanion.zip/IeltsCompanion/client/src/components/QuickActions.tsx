import { useState } from "react";
import { Clock, StickyNote, AlertTriangle } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Textarea } from "@/components/ui/textarea";
import { useToast } from "@/hooks/use-toast";

export default function QuickActions() {
  const [pomodoroActive, setPomodoroActive] = useState(false);
  const [pomodoroTime, setPomodoroTime] = useState(25 * 60); // 25 minutes in seconds
  const [note, setNote] = useState("");
  const [isNoteDialogOpen, setIsNoteDialogOpen] = useState(false);
  const { toast } = useToast();

  const startPomodoro = () => {
    setPomodoroActive(true);
    setPomodoroTime(25 * 60);
    
    const timer = setInterval(() => {
      setPomodoroTime((prev) => {
        if (prev <= 1) {
          clearInterval(timer);
          setPomodoroActive(false);
          toast({
            title: "Pomodoro hoàn thành!",
            description: "Hãy nghỉ ngơi 5 phút",
          });
          return 0;
        }
        return prev - 1;
      });
    }, 1000);

    toast({
      title: "Pomodoro bắt đầu",
      description: "25 phút tập trung học tập!",
    });
  };

  const stopPomodoro = () => {
    setPomodoroActive(false);
    setPomodoroTime(25 * 60);
  };

  const saveNote = () => {
    if (!note.trim()) return;
    
    // In a real app, this would save to the backend
    const notes = JSON.parse(localStorage.getItem('quickNotes') || '[]');
    notes.push({
      id: Date.now(),
      content: note,
      createdAt: new Date().toISOString()
    });
    localStorage.setItem('quickNotes', JSON.stringify(notes));
    
    setNote("");
    setIsNoteDialogOpen(false);
    toast({
      title: "Đã lưu ghi chú",
      description: "Ghi chú đã được lưu thành công",
    });
  };

  const reviewMistakes = () => {
    toast({
      title: "Tính năng đang phát triển",
      description: "Tính năng ôn lại lỗi sai sẽ sớm được cập nhật!",
    });
  };

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };

  return (
    <div className="bg-white rounded-2xl shadow-sm border border-gray-100 overflow-hidden">
      <div className="px-6 py-4 border-b border-gray-100">
        <h3 className="text-lg font-semibold text-gray-900">Hành động nhanh</h3>
      </div>
      
      <div className="p-6 space-y-3">
        <Button
          onClick={pomodoroActive ? stopPomodoro : startPomodoro}
          className={`w-full flex items-center justify-center px-4 py-3 rounded-lg transition-colors ${
            pomodoroActive 
              ? 'bg-red-50 text-red-700 hover:bg-red-100' 
              : 'bg-orange-50 text-orange-700 hover:bg-orange-100'
          }`}
          variant="ghost"
        >
          <Clock size={20} className="mr-3" />
          <span className="flex-1 text-left">
            {pomodoroActive ? `Dừng Pomodoro (${formatTime(pomodoroTime)})` : 'Bắt đầu Pomodoro (25 phút)'}
          </span>
        </Button>
        
        <Dialog open={isNoteDialogOpen} onOpenChange={setIsNoteDialogOpen}>
          <DialogTrigger asChild>
            <Button
              className="w-full flex items-center justify-center px-4 py-3 bg-purple-50 text-purple-700 rounded-lg hover:bg-purple-100 transition-colors"
              variant="ghost"
            >
              <StickyNote size={20} className="mr-3" />
              <span className="flex-1 text-left">Thêm ghi chú nhanh</span>
            </Button>
          </DialogTrigger>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Ghi chú nhanh</DialogTitle>
            </DialogHeader>
            <div className="space-y-4">
              <Textarea
                placeholder="Nhập ghi chú của bạn..."
                value={note}
                onChange={(e) => setNote(e.target.value)}
                rows={4}
              />
              <div className="flex gap-2">
                <Button onClick={saveNote} disabled={!note.trim()}>
                  Lưu ghi chú
                </Button>
                <Button 
                  variant="outline" 
                  onClick={() => setIsNoteDialogOpen(false)}
                >
                  Hủy
                </Button>
              </div>
            </div>
          </DialogContent>
        </Dialog>
        
        <Button
          onClick={reviewMistakes}
          className="w-full flex items-center justify-center px-4 py-3 bg-red-50 text-red-700 rounded-lg hover:bg-red-100 transition-colors"
          variant="ghost"
        >
          <AlertTriangle size={20} className="mr-3" />
          <span className="flex-1 text-left">Ôn lại lỗi sai</span>
        </Button>
      </div>
    </div>
  );
}
