import { useState } from "react";
import { useMutation } from "@tanstack/react-query";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { 
  Headphones, BookOpen, PenTool, Mic, Calendar, Clock, 
  Target, Star, Award, PlayCircle, CheckCircle2, BarChart3,
  Volume2, RotateCcw, FileText, MessageSquare, Timer,
  TrendingUp, Activity, Zap, Brain, Lightbulb, Flame, Circle
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useToast } from "@/hooks/use-toast";
import type { InsertTestResult } from "@shared/schema";

interface TestQuestion {
  id: number;
  question: string;
  options?: string[];
  correctAnswer: string;
  explanation: string;
  bandLevel: "5.0" | "5.5" | "6.0" | "6.5" | "7.0" | "7.5" | "8.0" | "8.5" | "9.0";
  skill: string;
}

const ieltsAdvancedContent = {
  listening: {
    icon: Headphones,
    title: "IELTS Listening - Band 5.0+",
    duration: "30 phút",
    questions: 40,
    color: "var(--pastel-blue)",
    description: "Luyện nghe đầy đủ 4 phần với độ khó tăng dần",
    skills: ["Note-taking", "Multiple choice", "Form completion", "Matching", "Map labeling"],
    parts: [
      {
        part: "Part 1",
        context: "Conversation in everyday social context",
        questionTypes: ["Form completion", "Multiple choice"],
        difficulty: "5.0-6.0"
      },
      {
        part: "Part 2", 
        context: "Monologue in everyday social context",
        questionTypes: ["Multiple choice", "Plan/map labeling"],
        difficulty: "5.5-6.5"
      },
      {
        part: "Part 3",
        context: "Conversation in educational/training context",
        questionTypes: ["Multiple choice", "Matching"],
        difficulty: "6.0-7.0"
      },
      {
        part: "Part 4",
        context: "Monologue on academic subject",
        questionTypes: ["Note completion", "Summary completion"],
        difficulty: "6.5-8.0"
      }
    ]
  },
  reading: {
    icon: BookOpen,
    title: "IELTS Reading - Band 5.0+",
    duration: "60 phút",
    questions: 40,
    color: "var(--pastel-green)",
    description: "Đọc hiểu 3 đoạn văn với độ khó Academic/General",
    skills: ["Skimming", "Scanning", "Detail reading", "Inference", "Vocabulary in context"],
    passages: [
      {
        passage: "Passage 1",
        length: "900 words",
        difficulty: "5.0-6.5",
        questionTypes: ["True/False/Not Given", "Multiple choice", "Completion"]
      },
      {
        passage: "Passage 2", 
        length: "900 words",
        difficulty: "6.0-7.0",
        questionTypes: ["Matching headings", "Multiple choice", "Short answers"]
      },
      {
        passage: "Passage 3",
        length: "900 words", 
        difficulty: "6.5-8.5",
        questionTypes: ["Matching information", "Summary completion", "Multiple choice"]
      }
    ]
  },
  writing: {
    icon: PenTool,
    title: "IELTS Writing - Band 5.0+",
    duration: "60 phút",
    questions: 2,
    color: "var(--pastel-purple)",
    description: "Luyện viết Task 1 và Task 2 với tiêu chí chấm điểm chính thức",
    skills: ["Task achievement", "Coherence & cohesion", "Lexical resource", "Grammar accuracy"],
    tasks: [
      {
        type: "Task 1",
        timeAllocation: "20 minutes",
        wordCount: "150+ words",
        bandCriteria: {
          "5.0": "Basic description with simple language",
          "6.0": "Clear overview with adequate vocabulary", 
          "7.0": "Clear trends with varied language",
          "8.0": "Sophisticated analysis with precise language"
        }
      },
      {
        type: "Task 2",
        timeAllocation: "40 minutes", 
        wordCount: "250+ words",
        bandCriteria: {
          "5.0": "Basic response with simple ideas",
          "6.0": "Relevant response with some development",
          "7.0": "Well-developed response with clear position",
          "8.0": "Sophisticated arguments with natural language"
        }
      }
    ]
  },
  speaking: {
    icon: Mic,
    title: "IELTS Speaking - Band 5.0+",
    duration: "11-14 phút", 
    questions: 3,
    color: "var(--pastel-pink)",
    description: "Luyện nói 3 phần với đánh giá theo tiêu chí chính thức",
    skills: ["Fluency", "Lexical resource", "Grammar range", "Pronunciation"],
    parts: [
      {
        part: "Part 1",
        duration: "4-5 minutes",
        format: "Introduction + familiar topics",
        bandFocus: {
          "5.0": "Simple responses with basic vocabulary",
          "6.0": "Extended responses with some variety",
          "7.0": "Flexible responses with good vocabulary",
          "8.0": "Natural responses with sophisticated language"
        }
      },
      {
        part: "Part 2",
        duration: "3-4 minutes", 
        format: "Long turn (2 minutes speaking)",
        bandFocus: {
          "5.0": "Basic coherent response covering points",
          "6.0": "Coherent response with some development",
          "7.0": "Well-organized response with good language",
          "8.0": "Sophisticated response with natural flow"
        }
      },
      {
        part: "Part 3",
        duration: "4-5 minutes",
        format: "Two-way discussion", 
        bandFocus: {
          "5.0": "Simple opinions with basic reasoning",
          "6.0": "Clear opinions with some justification",
          "7.0": "Well-developed ideas with good examples",
          "8.0": "Abstract concepts with sophisticated language"
        }
      }
    ]
  }
};

const dailyPlanning = {
  beginner: {
    bandTarget: "5.0-5.5",
    dailyTime: "2-3 hours",
    schedule: {
      listening: "30 min - Parts 1&2 focus",
      reading: "45 min - Basic passages",
      writing: "30 min - Simple task practice", 
      speaking: "15 min - Part 1 topics",
      vocabulary: "20 min - High-frequency words"
    }
  },
  intermediate: {
    bandTarget: "6.0-6.5", 
    dailyTime: "3-4 hours",
    schedule: {
      listening: "40 min - All parts practice",
      reading: "60 min - Mixed passages",
      writing: "45 min - Both tasks",
      speaking: "20 min - All parts",
      vocabulary: "25 min - Academic words"
    }
  },
  advanced: {
    bandTarget: "7.0+",
    dailyTime: "4-5 hours", 
    schedule: {
      listening: "45 min - Complex Parts 3&4",
      reading: "75 min - Academic passages",
      writing: "60 min - Advanced tasks",
      speaking: "30 min - Complex discussions",
      vocabulary: "30 min - Sophisticated expressions"
    }
  }
};

const miniTests = {
  quick: {
    duration: "15 minutes",
    questions: 10,
    skills: ["Listening Part 1", "Reading passage extract", "Vocabulary quiz"]
  },
  standard: {
    duration: "30 minutes", 
    questions: 20,
    skills: ["Listening Parts 1&2", "Reading passage", "Writing Task 1 planning"]
  },
  comprehensive: {
    duration: "60 minutes",
    questions: 40, 
    skills: ["Full section practice", "All question types", "Detailed feedback"]
  }
};

export default function IELTSAdvanced() {
  const [activeTab, setActiveTab] = useState("overview");
  const [selectedLevel, setSelectedLevel] = useState("intermediate");
  const [activeTest, setActiveTest] = useState<string | null>(null);
  const [currentSection, setCurrentSection] = useState(0);
  const [testProgress, setTestProgress] = useState(0);
  const [dailyGoals, setDailyGoals] = useState({
    listening: false,
    reading: false, 
    writing: false,
    speaking: false,
    vocabulary: false
  });

  const { toast } = useToast();

  const submitTestMutation = useMutation({
    mutationFn: async (result: InsertTestResult) => {
      const response = await apiRequest('POST', '/api/test-results', result);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/test-results'] });
      toast({
        title: "Test completed!",
        description: "Your results have been saved and analyzed",
      });
    },
  });

  const startTest = (testType: string, miniTestType?: string) => {
    setActiveTest(testType);
    setCurrentSection(0);
    setTestProgress(0);
    
    toast({
      title: "Test started",
      description: `Beginning ${testType} ${miniTestType || 'practice'}`,
    });
  };

  const completeSection = () => {
    const test = ieltsAdvancedContent[activeTest as keyof typeof ieltsAdvancedContent];
    if (!test) return;

    const sectionsCount = 'parts' in test ? test.parts.length : 
                         'passages' in test ? test.passages.length : 
                         'tasks' in test ? test.tasks.length : 3;

    if (currentSection < sectionsCount - 1) {
      setCurrentSection(prev => prev + 1);
      setTestProgress(((currentSection + 1) / sectionsCount) * 100);
    } else {
      // Complete test
      const score = Math.floor(Math.random() * 4) + 6; // Simulate band 6.0-9.0
      submitTestMutation.mutate({
        testType: `${activeTest}-advanced`,
        score: score * 10,
        totalQuestions: test.questions,
        answers: { sections: sectionsCount, level: selectedLevel }
      });
      
      setActiveTest(null);
      setTestProgress(0);
      setCurrentSection(0);
    }
  };

  const toggleDailyGoal = (skill: keyof typeof dailyGoals) => {
    setDailyGoals(prev => ({
      ...prev,
      [skill]: !prev[skill]
    }));
  };

  const getDailyPlan = () => {
    return dailyPlanning[selectedLevel as keyof typeof dailyPlanning];
  };

  const getCompletedGoals = () => {
    return Object.values(dailyGoals).filter(Boolean).length;
  };

  const getTotalGoals = () => {
    return Object.keys(dailyGoals).length;
  };

  const dailyPlan = getDailyPlan();
  const completedGoals = getCompletedGoals();
  const totalGoals = getTotalGoals();
  const dailyProgress = (completedGoals / totalGoals) * 100;

  return (
    <div className="space-y-6">
      {/* Level Selection & Daily Progress */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card className="pastel-card col-span-1 md:col-span-2" style={{ background: 'var(--pastel-blue)' }}>
          <CardContent className="p-4">
            <div className="flex items-center justify-between mb-3">
              <div>
                <h3 className="font-semibold text-blue-800">Mục tiêu hôm nay</h3>
                <p className="text-sm text-blue-600">{dailyPlan.bandTarget} • {dailyPlan.dailyTime}</p>
              </div>
              <div className="text-right">
                <p className="text-2xl font-bold text-blue-800">{completedGoals}/{totalGoals}</p>
                <p className="text-xs text-blue-600">Hoàn thành</p>
              </div>
            </div>
            <Progress value={dailyProgress} className="h-2" />
          </CardContent>
        </Card>

        <Card className="pastel-card" style={{ background: 'var(--pastel-green)' }}>
          <CardContent className="p-4">
            <div className="flex items-center">
              <Target className="text-green-700 mr-3" size={24} />
              <div>
                <p className="text-sm text-green-700">Target Band</p>
                <p className="text-xl font-bold text-green-800">{dailyPlan.bandTarget}</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="pastel-card" style={{ background: 'var(--pastel-purple)' }}>
          <CardContent className="p-4">
            <div className="flex items-center">
              <Flame className="text-purple-700 mr-3" size={24} />
              <div>
                <p className="text-sm text-purple-700">Streak</p>
                <p className="text-xl font-bold text-purple-800">15 ngày</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Main Content Tabs */}
      <Card className="pastel-card">
        <CardHeader style={{ background: 'var(--pastel-pink)' }}>
          <div className="flex items-center justify-between">
            <CardTitle className="text-pink-800">IELTS Practice Center - Band 5.0+</CardTitle>
            <Select value={selectedLevel} onValueChange={setSelectedLevel}>
              <SelectTrigger className="w-40 bg-white/80">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="beginner">Beginner (5.0-5.5)</SelectItem>
                <SelectItem value="intermediate">Intermediate (6.0-6.5)</SelectItem>
                <SelectItem value="advanced">Advanced (7.0+)</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </CardHeader>

        <CardContent className="p-6">
          <Tabs value={activeTab} onValueChange={setActiveTab}>
            <TabsList className="grid w-full grid-cols-5">
              <TabsTrigger value="overview">Tổng quan</TabsTrigger>
              <TabsTrigger value="daily">Kế hoạch hàng ngày</TabsTrigger>
              <TabsTrigger value="practice">Luyện tập</TabsTrigger>
              <TabsTrigger value="minitest">Mini Test</TabsTrigger>
              <TabsTrigger value="analytics">Thống kê</TabsTrigger>
            </TabsList>

            <TabsContent value="overview" className="mt-6">
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
                {Object.entries(ieltsAdvancedContent).map(([key, skill]) => {
                  const IconComponent = skill.icon;
                  return (
                    <Card 
                      key={key} 
                      className="pastel-card hover:shadow-lg transition-all cursor-pointer group"
                      style={{ background: skill.color }}
                      onClick={() => startTest(key)}
                    >
                      <CardContent className="p-6">
                        <div className="text-center">
                          <div className="w-12 h-12 mx-auto mb-3 rounded-lg bg-white/30 flex items-center justify-center group-hover:scale-110 transition-transform">
                            <IconComponent size={24} className="text-white" />
                          </div>
                          <h3 className="font-semibold text-white mb-2">{skill.title}</h3>
                          <div className="space-y-1 text-xs text-white/80">
                            <p>⏱️ {skill.duration}</p>
                            <p>📝 {skill.questions} câu hỏi</p>
                          </div>
                          <div className="mt-3">
                            <Badge className="bg-white/20 text-white border-0">
                              Band 5.0+
                            </Badge>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  );
                })}
              </div>
            </TabsContent>

            <TabsContent value="daily" className="mt-6">
              <div className="space-y-6">
                <div className="text-center mb-6">
                  <h3 className="text-xl font-semibold mb-2">Kế hoạch học tập hàng ngày</h3>
                  <p className="text-gray-600">Cấp độ: {selectedLevel} • Mục tiêu: {dailyPlan.bandTarget}</p>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                  {Object.entries(dailyPlan.schedule).map(([skill, timeDesc]) => {
                    const isCompleted = dailyGoals[skill as keyof typeof dailyGoals];
                    const skillConfig = {
                      listening: { icon: Headphones, color: 'var(--pastel-blue)' },
                      reading: { icon: BookOpen, color: 'var(--pastel-green)' },
                      writing: { icon: PenTool, color: 'var(--pastel-purple)' },
                      speaking: { icon: Mic, color: 'var(--pastel-pink)' },
                      vocabulary: { icon: Brain, color: 'var(--pastel-orange)' }
                    }[skill] || { icon: Target, color: 'var(--pastel-mint)' };

                    const IconComponent = skillConfig.icon;

                    return (
                      <Card 
                        key={skill}
                        className={`pastel-card cursor-pointer transition-all ${isCompleted ? 'opacity-75' : 'hover:shadow-lg'}`}
                        style={{ background: skillConfig.color }}
                        onClick={() => toggleDailyGoal(skill as keyof typeof dailyGoals)}
                      >
                        <CardContent className="p-4">
                          <div className="flex items-center justify-between">
                            <div className="flex items-center">
                              <IconComponent size={20} className="text-white mr-3" />
                              <div>
                                <h4 className="font-medium text-white capitalize">{skill}</h4>
                                <p className="text-sm text-white/80">{timeDesc}</p>
                              </div>
                            </div>
                            <div className="text-white">
                              {isCompleted ? <CheckCircle2 size={20} /> : <Circle size={20} />}
                            </div>
                          </div>
                        </CardContent>
                      </Card>
                    );
                  })}
                </div>

                <Card className="pastel-card" style={{ background: 'var(--pastel-yellow)' }}>
                  <CardContent className="p-4">
                    <div className="flex items-center justify-between">
                      <div>
                        <h4 className="font-medium text-yellow-800">Tổng thời gian học hôm nay</h4>
                        <p className="text-sm text-yellow-700">Mục tiêu: {dailyPlan.dailyTime}</p>
                      </div>
                      <div className="text-right">
                        <p className="text-2xl font-bold text-yellow-800">{Math.round(dailyProgress)}%</p>
                        <p className="text-xs text-yellow-700">Hoàn thành</p>
                      </div>
                    </div>
                    <Progress value={dailyProgress} className="mt-3 h-2" />
                  </CardContent>
                </Card>
              </div>
            </TabsContent>

            <TabsContent value="practice" className="mt-6">
              {activeTest ? (
                <div className="space-y-6">
                  <div className="flex items-center justify-between">
                    <h3 className="text-xl font-semibold">
                      {ieltsAdvancedContent[activeTest as keyof typeof ieltsAdvancedContent].title}
                    </h3>
                    <Button onClick={() => setActiveTest(null)} variant="outline">
                      Thoát bài thi
                    </Button>
                  </div>

                  <Card className="pastel-card">
                    <CardContent className="p-6">
                      <div className="mb-4">
                        <div className="flex items-center justify-between mb-2">
                          <span className="text-sm font-medium">Tiến độ bài thi</span>
                          <span className="text-sm text-gray-600">{Math.round(testProgress)}%</span>
                        </div>
                        <Progress value={testProgress} className="h-2" />
                      </div>

                      <div className="text-center py-12">
                        <div className="w-16 h-16 mx-auto mb-4 rounded-full flex items-center justify-center" 
                             style={{ background: ieltsAdvancedContent[activeTest as keyof typeof ieltsAdvancedContent].color }}>
                          <Timer className="text-white" size={32} />
                        </div>
                        <h4 className="text-lg font-semibold mb-2">
                          Phần {currentSection + 1} đang diễn ra
                        </h4>
                        <p className="text-gray-600 mb-6">
                          Thực hiện theo hướng dẫn và nhấn "Hoàn thành phần" khi xong
                        </p>
                        <Button 
                          onClick={completeSection}
                          className="pastel-purple-gradient text-purple-800"
                          disabled={submitTestMutation.isPending}
                        >
                          {submitTestMutation.isPending ? 'Đang xử lý...' : 'Hoàn thành phần này'}
                        </Button>
                      </div>
                    </CardContent>
                  </Card>
                </div>
              ) : (
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  {Object.entries(ieltsAdvancedContent).map(([key, skill]) => {
                    const IconComponent = skill.icon;
                    return (
                      <Card 
                        key={key}
                        className="pastel-card hover:shadow-lg transition-all cursor-pointer"
                        onClick={() => startTest(key)}
                      >
                        <CardContent className="p-6">
                          <div className="flex items-start space-x-4">
                            <div 
                              className="w-12 h-12 rounded-lg flex items-center justify-center"
                              style={{ background: skill.color }}
                            >
                              <IconComponent size={24} className="text-white" />
                            </div>
                            <div className="flex-1">
                              <h3 className="font-semibold mb-2">{skill.title}</h3>
                              <p className="text-sm text-gray-600 mb-3">{skill.description}</p>
                              <div className="flex items-center gap-4 text-xs text-gray-500 mb-3">
                                <span>⏱️ {skill.duration}</span>
                                <span>📝 {skill.questions} câu</span>
                              </div>
                              <div className="space-y-1">
                                <p className="text-xs font-medium text-gray-700">Kỹ năng luyện tập:</p>
                                <div className="flex flex-wrap gap-1">
                                  {skill.skills.slice(0, 3).map((skillItem, i) => (
                                    <Badge key={i} variant="outline" className="text-xs">
                                      {skillItem}
                                    </Badge>
                                  ))}
                                  {skill.skills.length > 3 && (
                                    <Badge variant="outline" className="text-xs">
                                      +{skill.skills.length - 3}
                                    </Badge>
                                  )}
                                </div>
                              </div>
                            </div>
                          </div>
                        </CardContent>
                      </Card>
                    );
                  })}
                </div>
              )}
            </TabsContent>

            <TabsContent value="minitest" className="mt-6">
              <div className="space-y-6">
                <div className="text-center">
                  <h3 className="text-xl font-semibold mb-2">Mini Tests IELTS</h3>
                  <p className="text-gray-600">Kiểm tra nhanh kỹ năng với các bài test ngắn</p>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  {Object.entries(miniTests).map(([testType, testInfo]) => (
                    <Card 
                      key={testType}
                      className="pastel-card hover:shadow-lg transition-all cursor-pointer"
                      style={{ 
                        background: testType === 'quick' ? 'var(--pastel-green)' :
                                   testType === 'standard' ? 'var(--pastel-blue)' : 'var(--pastel-purple)'
                      }}
                      onClick={() => startTest('minitest', testType)}
                    >
                      <CardContent className="p-6 text-center">
                        <div className="w-12 h-12 mx-auto mb-3 rounded-lg bg-white/30 flex items-center justify-center">
                          <Zap className="text-white" size={24} />
                        </div>
                        <h4 className="font-semibold text-white mb-2 capitalize">
                          {testType === 'quick' ? 'Quick Test' : 
                           testType === 'standard' ? 'Standard Test' : 'Comprehensive Test'}
                        </h4>
                        <div className="space-y-1 text-sm text-white/80">
                          <p>⏱️ {testInfo.duration}</p>
                          <p>📝 {testInfo.questions} câu hỏi</p>
                        </div>
                        <div className="mt-3 space-y-1">
                          {testInfo.skills.map((skill, i) => (
                            <Badge key={i} className="bg-white/20 text-white border-0 text-xs mr-1">
                              {skill}
                            </Badge>
                          ))}
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              </div>
            </TabsContent>

            <TabsContent value="analytics" className="mt-6">
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
                <Card className="pastel-card" style={{ background: 'var(--pastel-blue)' }}>
                  <CardContent className="p-4">
                    <div className="flex items-center">
                      <TrendingUp className="text-blue-700 mr-3" size={24} />
                      <div>
                        <p className="text-sm text-blue-700">Điểm TB tuần</p>
                        <p className="text-xl font-bold text-blue-800">6.8</p>
                      </div>
                    </div>
                  </CardContent>
                </Card>

                <Card className="pastel-card" style={{ background: 'var(--pastel-green)' }}>
                  <CardContent className="p-4">
                    <div className="flex items-center">
                      <Clock className="text-green-700 mr-3" size={24} />
                      <div>
                        <p className="text-sm text-green-700">Thời gian học</p>
                        <p className="text-xl font-bold text-green-800">28h</p>
                      </div>
                    </div>
                  </CardContent>
                </Card>

                <Card className="pastel-card" style={{ background: 'var(--pastel-purple)' }}>
                  <CardContent className="p-4">
                    <div className="flex items-center">
                      <Activity className="text-purple-700 mr-3" size={24} />
                      <div>
                        <p className="text-sm text-purple-700">Tests hoàn thành</p>
                        <p className="text-xl font-bold text-purple-800">47</p>
                      </div>
                    </div>
                  </CardContent>
                </Card>

                <Card className="pastel-card" style={{ background: 'var(--pastel-pink)' }}>
                  <CardContent className="p-4">
                    <div className="flex items-center">
                      <Award className="text-pink-700 mr-3" size={24} />
                      <div>
                        <p className="text-sm text-pink-700">Cải thiện</p>
                        <p className="text-xl font-bold text-pink-800">+1.2</p>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <Card className="pastel-card">
                  <CardHeader>
                    <CardTitle className="text-lg">Tiến độ theo kỹ năng</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      {Object.entries(ieltsAdvancedContent).map(([skill, data]) => (
                        <div key={skill}>
                          <div className="flex justify-between text-sm mb-1">
                            <span className="capitalize">{skill}</span>
                            <span>6.{Math.floor(Math.random() * 5) + 3}</span>
                          </div>
                          <Progress value={60 + Math.random() * 35} className="h-2" />
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>

                <Card className="pastel-card">
                  <CardHeader>
                    <CardTitle className="text-lg">Mục tiêu tháng này</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      <div className="flex items-center justify-between p-3 bg-blue-50 rounded-lg">
                        <div className="flex items-center">
                          <Target className="text-blue-600 mr-2" size={16} />
                          <span className="text-sm">Đạt band 7.0 overall</span>
                        </div>
                        <Badge className="bg-blue-100 text-blue-800">85%</Badge>
                      </div>
                      <div className="flex items-center justify-between p-3 bg-green-50 rounded-lg">
                        <div className="flex items-center">
                          <Lightbulb className="text-green-600 mr-2" size={16} />
                          <span className="text-sm">Học 500 từ vựng mới</span>
                        </div>
                        <Badge className="bg-green-100 text-green-800">67%</Badge>
                      </div>
                      <div className="flex items-center justify-between p-3 bg-purple-50 rounded-lg">
                        <div className="flex items-center">
                          <Clock className="text-purple-600 mr-2" size={16} />
                          <span className="text-sm">100 giờ luyện tập</span>
                        </div>
                        <Badge className="bg-purple-100 text-purple-800">28%</Badge>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </div>
            </TabsContent>
          </Tabs>
        </CardContent>
      </Card>
    </div>
  );
}