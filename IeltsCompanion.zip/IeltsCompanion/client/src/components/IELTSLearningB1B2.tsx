import { useState } from "react";
import { useMutation } from "@tanstack/react-query";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { 
  Headphones, BookOpen, PenTool, Mic, TrendingUp, Clock, 
  Flame, Target, Star, Award, PlayCircle, CheckCircle2,
  Volume2, RotateCcw, FileText, MessageSquare
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useToast } from "@/hooks/use-toast";
import type { InsertTestResult } from "@shared/schema";

interface TestQuestion {
  id: number;
  question: string;
  options?: string[];
  correctAnswer: string;
  explanation: string;
  difficulty: "B1" | "B2";
  skill: string;
}

const ieltsB1B2Content = {
  listening: {
    icon: Headphones,
    title: "Listening - B1/B2 Level",
    targetBand: "6.5-7.0",
    duration: "12 phút",
    questions: 8,
    color: "bg-blue-100 text-blue-600",
    description: "Luyện nghe với âm thanh thực tế, tập trung vào kỹ năng cần thiết cho band 6.5-7.0",
    skills: ["Note-taking", "Detail comprehension", "Main idea identification", "Inference"],
    questions_data: [
      {
        id: 1,
        question: "What is the main purpose of the conversation between Sarah and the receptionist?",
        options: [
          "A) To book a room for vacation",
          "B) To enquire about gym membership rates", 
          "C) To complain about service quality",
          "D) To reschedule an appointment"
        ],
        correctAnswer: "B",
        explanation: "Sarah specifically asks about different membership options and their costs, indicating she wants information about gym membership rates.",
        difficulty: "B1" as const,
        skill: "Main idea identification"
      },
      {
        id: 2,
        question: "According to the receptionist, what discount is available for students?",
        options: [
          "A) 15% off monthly fees",
          "B) 20% off annual membership",
          "C) Free trial week",
          "D) Reduced registration fee"
        ],
        correctAnswer: "B",
        explanation: "The receptionist clearly states that students receive a 20% discount on annual membership with valid student ID.",
        difficulty: "B1" as const,
        skill: "Detail comprehension"
      },
      {
        id: 3,
        question: "What can be inferred about Sarah's current situation?",
        options: [
          "A) She is unemployed",
          "B) She is a university student",
          "C) She lives far from the gym",
          "D) She has used this gym before"
        ],
        correctAnswer: "B",
        explanation: "Sarah asks about student discounts and mentions her university schedule, indicating she is currently a student.",
        difficulty: "B2" as const,
        skill: "Inference"
      }
    ]
  },
  reading: {
    icon: BookOpen,
    title: "Reading - B1/B2 Level",
    targetBand: "6.5-7.0",
    duration: "20 phút",
    questions: 10,
    color: "bg-green-100 text-green-600",
    description: "Đọc hiểu với các văn bản học thuật và thực tế, phát triển kỹ năng scan và skim",
    skills: ["Skimming", "Scanning", "Paraphrasing", "Academic vocabulary"],
    questions_data: [
      {
        id: 1,
        question: "According to the passage, what is the primary factor driving renewable energy adoption in developing countries?",
        options: [
          "A) Environmental regulations",
          "B) Economic incentives and cost reduction",
          "C) International pressure",
          "D) Technological advancement"
        ],
        correctAnswer: "B",
        explanation: "The passage emphasizes that falling costs and economic benefits are the main drivers, not just environmental concerns.",
        difficulty: "B2" as const,
        skill: "Main idea identification"
      },
      {
        id: 2,
        question: "The word 'proliferation' in paragraph 3 is closest in meaning to:",
        options: [
          "A) Development",
          "B) Rapid increase",
          "C) Implementation", 
          "D) Investment"
        ],
        correctAnswer: "B",
        explanation: "'Proliferation' means rapid increase or spread, which fits the context of renewable energy expansion.",
        difficulty: "B2" as const,
        skill: "Academic vocabulary"
      }
    ]
  },
  writing: {
    icon: PenTool,
    title: "Writing - B1/B2 Level",
    targetBand: "6.5-7.0",
    duration: "60 phút",
    questions: 2,
    color: "bg-yellow-100 text-yellow-600",
    description: "Luyện viết Task 1 (biểu đồ, bảng) và Task 2 (essay) với cấu trúc và từ vựng phù hợp",
    skills: ["Task 1: Data analysis", "Task 2: Essay structure", "Academic vocabulary", "Coherence & cohesion"],
    tasks: [
      {
        type: "Task 1 - Bar Chart",
        prompt: "The chart below shows the percentage of people using different transportation methods in three cities in 2020. Summarise the information by selecting and reporting the main features, and make comparisons where relevant. (150 words minimum)",
        bandRequirements: {
          "6.5": "Clear overview, accurate data, good range of vocabulary",
          "7.0": "Clear trend identification, effective comparisons, precise language"
        }
      },
      {
        type: "Task 2 - Opinion Essay", 
        prompt: "Some people believe that university education should be free for all students. Others think that students should pay for their education. Discuss both views and give your own opinion. (250 words minimum)",
        bandRequirements: {
          "6.5": "Clear position, relevant examples, good paragraphing",
          "7.0": "Well-developed arguments, varied sentence structures, natural language"
        }
      }
    ]
  },
  speaking: {
    icon: Mic,
    title: "Speaking - B1/B2 Level", 
    targetBand: "6.5-7.0",
    duration: "12 phút",
    questions: 3,
    color: "bg-purple-100 text-purple-600",
    description: "Luyện nói theo format chính thức IELTS với các chủ đề phù hợp trình độ B1-B2",
    skills: ["Fluency", "Pronunciation", "Grammar range", "Lexical resource"],
    parts: [
      {
        part: "Part 1 - Introduction",
        duration: "4-5 minutes",
        topics: ["Work/Study", "Hometown", "Hobbies", "Food", "Technology"],
        sampleQuestions: [
          "Do you work or study?",
          "What do you like most about your hometown?",
          "How often do you use technology in your daily life?",
          "What kind of food do you enjoy eating?"
        ],
        bandTips: {
          "6.5": "Speak naturally, use a range of vocabulary, extend answers appropriately",
          "7.0": "Show flexibility, use idiomatic language, maintain natural conversation flow"
        }
      },
      {
        part: "Part 2 - Long Turn",
        duration: "3-4 minutes",
        description: "Describe a skill you would like to learn in the future",
        cueCard: {
          mainTopic: "Describe a skill you would like to learn in the future",
          points: [
            "What the skill is",
            "Why you want to learn it", 
            "How you plan to learn it",
            "How this skill might benefit you"
          ],
          prepTime: "1 minute",
          speakTime: "2 minutes"
        },
        bandTips: {
          "6.5": "Cover all points, speak for full 2 minutes, use connecting words",
          "7.0": "Develop points naturally, use varied vocabulary, show clear organization"
        }
      },
      {
        part: "Part 3 - Discussion",
        duration: "4-5 minutes", 
        topics: ["Learning and Education", "Skills for the Future", "Technology and Learning"],
        sampleQuestions: [
          "How do you think technology has changed the way people learn?",
          "What skills do you think will be most important in the future?",
          "Should schools focus more on practical skills or academic subjects?"
        ],
        bandTips: {
          "6.5": "Discuss ideas clearly, give reasons for opinions, use abstract language",
          "7.0": "Show depth of thinking, use sophisticated vocabulary, make connections between ideas"
        }
      }
    ]
  }
};

export default function IELTSLearningB1B2() {
  const [activeTest, setActiveTest] = useState<string | null>(null);
  const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0);
  const [userAnswers, setUserAnswers] = useState<Record<number, string>>({});
  const [testCompleted, setTestCompleted] = useState(false);
  const [showExplanation, setShowExplanation] = useState(false);
  const [currentPart, setCurrentPart] = useState(0);
  const { toast } = useToast();

  const submitTestMutation = useMutation({
    mutationFn: async (result: InsertTestResult) => {
      const response = await apiRequest('POST', '/api/test-results', result);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/test-results'] });
      toast({
        title: "Hoàn thành!",
        description: "Kết quả bài test B1-B2 đã được lưu",
      });
    },
  });

  const startTest = (testType: string) => {
    setActiveTest(testType);
    setCurrentQuestionIndex(0);
    setCurrentPart(0);
    setUserAnswers({});
    setTestCompleted(false);
    setShowExplanation(false);
  };

  const selectAnswer = (questionId: number, answer: string) => {
    setUserAnswers(prev => ({
      ...prev,
      [questionId]: answer
    }));
  };

  const nextQuestion = () => {
    if (!activeTest) return;
    const test = ieltsB1B2Content[activeTest as keyof typeof ieltsB1B2Content];
    
    if ('questions_data' in test && currentQuestionIndex < test.questions_data.length - 1) {
      setCurrentQuestionIndex(prev => prev + 1);
      setShowExplanation(false);
    } else {
      submitTest();
    }
  };

  const submitTest = () => {
    if (!activeTest) return;
    
    const test = ieltsB1B2Content[activeTest as keyof typeof ieltsB1B2Content];
    if ('questions_data' in test) {
      const correctAnswers = test.questions_data.filter(q => 
        userAnswers[q.id] === q.correctAnswer
      ).length;
      
      const percentage = (correctAnswers / test.questions_data.length) * 100;
      let estimatedBand = 5.0;
      
      if (percentage >= 85) estimatedBand = 7.0;
      else if (percentage >= 75) estimatedBand = 6.5;
      else if (percentage >= 65) estimatedBand = 6.0;
      else if (percentage >= 55) estimatedBand = 5.5;
      
      submitTestMutation.mutate({
        testType: `${activeTest}-B1B2`,
        score: Math.round(estimatedBand * 10),
        totalQuestions: test.questions_data.length,
        answers: { userAnswers, correctAnswers, estimatedBand }
      });
      
      setTestCompleted(true);
      setTimeout(() => {
        setActiveTest(null);
        setTestCompleted(false);
      }, 4000);
    }
  };

  const renderListeningTest = () => {
    const test = ieltsB1B2Content.listening;
    const currentQuestion = test.questions_data[currentQuestionIndex];
    
    return (
      <div className="space-y-6">
        <div className="bg-blue-50 rounded-lg p-4">
          <div className="flex items-center justify-between mb-4">
            <h3 className="font-semibold">IELTS Listening Practice - B1/B2 Level</h3>
            <Badge className="bg-blue-600 text-white">
              Question {currentQuestionIndex + 1} of {test.questions_data.length}
            </Badge>
          </div>
          
          <div className="bg-white rounded-lg p-4 mb-4">
            <div className="flex items-center gap-4 mb-4">
              <Button variant="outline" className="flex items-center gap-2">
                <PlayCircle size={16} />
                Play Audio
              </Button>
              <Button variant="outline" size="sm">
                <Volume2 size={14} />
              </Button>
              <Button variant="outline" size="sm">
                <RotateCcw size={14} />
              </Button>
            </div>
            <div className="text-sm text-gray-600 bg-gray-50 p-3 rounded">
              🎧 Audio transcript: "Good morning, I'm calling to enquire about your gym membership options. I'm particularly interested in the rates for students as I'm currently studying at the university..."
            </div>
          </div>
          
          <div className="bg-white rounded-lg p-4">
            <p className="font-medium mb-4">{currentQuestion.question}</p>
            <div className="space-y-2">
              {currentQuestion.options?.map((option) => (
                <label key={option} className="flex items-center cursor-pointer p-2 rounded hover:bg-gray-50">
                  <input
                    type="radio"
                    name={`question-${currentQuestion.id}`}
                    value={option.charAt(0)}
                    checked={userAnswers[currentQuestion.id] === option.charAt(0)}
                    onChange={(e) => selectAnswer(currentQuestion.id, e.target.value)}
                    className="mr-3 text-blue-600"
                  />
                  <span>{option}</span>
                </label>
              ))}
            </div>
            
            {showExplanation && (
              <div className="mt-4 p-3 bg-green-50 rounded-lg">
                <p className="text-sm font-medium text-green-800 mb-1">Explanation:</p>
                <p className="text-sm text-green-700">{currentQuestion.explanation}</p>
                <div className="flex items-center gap-2 mt-2">
                  <Badge variant="outline" className="text-xs">
                    {currentQuestion.difficulty} Level
                  </Badge>
                  <Badge variant="outline" className="text-xs">
                    {currentQuestion.skill}
                  </Badge>
                </div>
              </div>
            )}
          </div>
          
          <div className="flex justify-between mt-4">
            <Button 
              variant="outline" 
              onClick={() => setShowExplanation(!showExplanation)}
              disabled={!userAnswers[currentQuestion.id]}
            >
              {showExplanation ? 'Hide' : 'Show'} Explanation
            </Button>
            <Button 
              onClick={nextQuestion}
              disabled={!userAnswers[currentQuestion.id]}
              className="bg-blue-600 text-white"
            >
              {currentQuestionIndex === test.questions_data.length - 1 ? 'Finish Test' : 'Next Question'}
            </Button>
          </div>
        </div>
      </div>
    );
  };

  const renderReadingTest = () => {
    const test = ieltsB1B2Content.reading;
    const currentQuestion = test.questions_data[currentQuestionIndex];
    
    return (
      <div className="space-y-6">
        <div className="bg-green-50 rounded-lg p-4">
          <div className="flex items-center justify-between mb-4">
            <h3 className="font-semibold">IELTS Reading Practice - B1/B2 Level</h3>
            <Badge className="bg-green-600 text-white">
              Question {currentQuestionIndex + 1} of {test.questions_data.length}
            </Badge>
          </div>
          
          <div className="bg-white rounded-lg p-6 mb-4">
            <h4 className="font-semibold mb-3">Renewable Energy in Developing Countries</h4>
            <div className="text-sm leading-relaxed space-y-3">
              <p>
                The adoption of renewable energy technologies in developing countries has accelerated dramatically over the past decade. While environmental considerations play a role, economic factors have emerged as the primary driver behind this transformation. The proliferation of solar and wind installations across Africa, Asia, and Latin America demonstrates how cost reduction and improved technology have made clean energy not just environmentally sound, but economically advantageous.
              </p>
              <p>
                Government incentives, international funding, and private investment have created a favorable ecosystem for renewable energy development. Countries like India and Brazil have implemented ambitious targets, while smaller nations in sub-Saharan Africa are leapfrogging traditional energy infrastructure by investing directly in renewable solutions.
              </p>
              <p>
                The proliferation of microgrids and distributed energy systems has enabled rural communities to access electricity for the first time, transforming education, healthcare, and economic opportunities. This decentralized approach contrasts sharply with the centralized fossil fuel-based systems traditionally favored in developed nations.
              </p>
            </div>
          </div>
          
          <div className="bg-white rounded-lg p-4">
            <p className="font-medium mb-4">{currentQuestion.question}</p>
            <div className="space-y-2">
              {currentQuestion.options?.map((option) => (
                <label key={option} className="flex items-center cursor-pointer p-2 rounded hover:bg-gray-50">
                  <input
                    type="radio"
                    name={`question-${currentQuestion.id}`}
                    value={option.charAt(0)}
                    checked={userAnswers[currentQuestion.id] === option.charAt(0)}
                    onChange={(e) => selectAnswer(currentQuestion.id, e.target.value)}
                    className="mr-3 text-green-600"
                  />
                  <span>{option}</span>
                </label>
              ))}
            </div>
            
            {showExplanation && (
              <div className="mt-4 p-3 bg-green-50 rounded-lg">
                <p className="text-sm font-medium text-green-800 mb-1">Explanation:</p>
                <p className="text-sm text-green-700">{currentQuestion.explanation}</p>
                <div className="flex items-center gap-2 mt-2">
                  <Badge variant="outline" className="text-xs">
                    {currentQuestion.difficulty} Level
                  </Badge>
                  <Badge variant="outline" className="text-xs">
                    {currentQuestion.skill}
                  </Badge>
                </div>
              </div>
            )}
          </div>
          
          <div className="flex justify-between mt-4">
            <Button 
              variant="outline" 
              onClick={() => setShowExplanation(!showExplanation)}
              disabled={!userAnswers[currentQuestion.id]}
            >
              {showExplanation ? 'Hide' : 'Show'} Explanation
            </Button>
            <Button 
              onClick={nextQuestion}
              disabled={!userAnswers[currentQuestion.id]}
              className="bg-green-600 text-white"
            >
              {currentQuestionIndex === test.questions_data.length - 1 ? 'Finish Test' : 'Next Question'}
            </Button>
          </div>
        </div>
      </div>
    );
  };

  const renderWritingPractice = () => {
    const test = ieltsB1B2Content.writing;
    
    return (
      <div className="space-y-6">
        <div className="bg-yellow-50 rounded-lg p-4">
          <h3 className="font-semibold mb-4">IELTS Writing Practice - B1/B2 Level</h3>
          
          <Tabs defaultValue="task1">
            <TabsList className="grid w-full grid-cols-2">
              <TabsTrigger value="task1">Task 1 - Data Analysis</TabsTrigger>
              <TabsTrigger value="task2">Task 2 - Essay</TabsTrigger>
            </TabsList>
            
            <TabsContent value="task1" className="mt-4">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg flex items-center gap-2">
                    <FileText size={20} />
                    Task 1 Practice (20 minutes)
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="bg-white p-4 rounded border">
                      <p className="font-medium mb-2">Bar Chart Analysis:</p>
                      <p className="text-sm">{test.tasks[0].prompt}</p>
                    </div>
                    
                    <div className="bg-gray-100 p-4 rounded">
                      <p className="text-xs font-medium mb-2">Band Score Requirements:</p>
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-2 text-xs">
                        <div>
                          <span className="font-medium">Band 6.5:</span> {test.tasks[0].bandRequirements["6.5"]}
                        </div>
                        <div>
                          <span className="font-medium">Band 7.0:</span> {test.tasks[0].bandRequirements["7.0"]}
                        </div>
                      </div>
                    </div>
                    
                    <textarea 
                      className="w-full h-40 p-3 border rounded-lg"
                      placeholder="Write your Task 1 response here... (150 words minimum)"
                    />
                    
                    <div className="flex justify-between items-center">
                      <span className="text-sm text-gray-600">Word count: 0/150</span>
                      <Button className="bg-yellow-600 text-white">Submit Task 1</Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
            
            <TabsContent value="task2" className="mt-4">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg flex items-center gap-2">
                    <MessageSquare size={20} />
                    Task 2 Practice (40 minutes)
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="bg-white p-4 rounded border">
                      <p className="font-medium mb-2">Opinion Essay:</p>
                      <p className="text-sm">{test.tasks[1].prompt}</p>
                    </div>
                    
                    <div className="bg-gray-100 p-4 rounded">
                      <p className="text-xs font-medium mb-2">Band Score Requirements:</p>
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-2 text-xs">
                        <div>
                          <span className="font-medium">Band 6.5:</span> {test.tasks[1].bandRequirements["6.5"]}
                        </div>
                        <div>
                          <span className="font-medium">Band 7.0:</span> {test.tasks[1].bandRequirements["7.0"]}
                        </div>
                      </div>
                    </div>
                    
                    <textarea 
                      className="w-full h-48 p-3 border rounded-lg"
                      placeholder="Write your Task 2 essay here... (250 words minimum)"
                    />
                    
                    <div className="flex justify-between items-center">
                      <span className="text-sm text-gray-600">Word count: 0/250</span>
                      <Button className="bg-yellow-600 text-white">Submit Task 2</Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </div>
      </div>
    );
  };

  const renderSpeakingPractice = () => {
    const test = ieltsB1B2Content.speaking;
    const currentSpeakingPart = test.parts[currentPart];
    
    return (
      <div className="space-y-6">
        <div className="bg-purple-50 rounded-lg p-4">
          <div className="flex items-center justify-between mb-4">
            <h3 className="font-semibold">IELTS Speaking Practice - B1/B2 Level</h3>
            <Badge className="bg-purple-600 text-white">
              {currentSpeakingPart.part}
            </Badge>
          </div>
          
          <Card>
            <CardHeader>
              <CardTitle className="text-lg flex items-center gap-2">
                <Mic size={20} />
                {currentSpeakingPart.part} - {currentSpeakingPart.duration}
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {currentPart === 0 && (
                  <div>
                    <p className="text-sm mb-3">{currentSpeakingPart.description || "Introduction and general questions"}</p>
                    <div className="bg-white p-4 rounded border">
                      <p className="font-medium mb-2">Sample Questions:</p>
                      <ul className="text-sm space-y-1">
                        {currentSpeakingPart.sampleQuestions?.map((q, i) => (
                          <li key={i} className="flex items-start gap-2">
                            <span className="text-purple-600">•</span>
                            {q}
                          </li>
                        ))}
                      </ul>
                    </div>
                  </div>
                )}
                
                {currentPart === 1 && (
                  <div>
                    <div className="bg-white p-4 rounded border mb-4">
                      <p className="font-medium mb-2">Cue Card Topic:</p>
                      <p className="text-lg font-medium text-purple-800 mb-3">
                        {currentSpeakingPart.cueCard?.mainTopic}
                      </p>
                      <p className="text-sm mb-2">You should say:</p>
                      <ul className="text-sm space-y-1 mb-3">
                        {currentSpeakingPart.cueCard?.points.map((point, i) => (
                          <li key={i} className="flex items-start gap-2">
                            <span className="text-purple-600">•</span>
                            {point}
                          </li>
                        ))}
                      </ul>
                      <p className="text-xs text-gray-600">
                        Preparation time: {currentSpeakingPart.cueCard?.prepTime} | 
                        Speaking time: {currentSpeakingPart.cueCard?.speakTime}
                      </p>
                    </div>
                    
                    <div className="flex gap-2">
                      <Button variant="outline">Start Preparation</Button>
                      <Button className="bg-purple-600 text-white">Start Speaking</Button>
                    </div>
                  </div>
                )}
                
                {currentPart === 2 && (
                  <div>
                    <p className="text-sm mb-3">Discussion based on Part 2 topic</p>
                    <div className="bg-white p-4 rounded border">
                      <p className="font-medium mb-2">Discussion Questions:</p>
                      <ul className="text-sm space-y-2">
                        {currentSpeakingPart.sampleQuestions?.map((q, i) => (
                          <li key={i} className="flex items-start gap-2 p-2 bg-gray-50 rounded">
                            <span className="text-purple-600 font-bold">{i + 1}.</span>
                            {q}
                          </li>
                        ))}
                      </ul>
                    </div>
                  </div>
                )}
                
                <div className="bg-gray-100 p-3 rounded">
                  <p className="text-xs font-medium mb-2">Band Score Tips:</p>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-2 text-xs">
                    <div>
                      <span className="font-medium">Band 6.5:</span> {currentSpeakingPart.bandTips["6.5"]}
                    </div>
                    <div>
                      <span className="font-medium">Band 7.0:</span> {currentSpeakingPart.bandTips["7.0"]}
                    </div>
                  </div>
                </div>
                
                <div className="flex justify-between">
                  <Button 
                    variant="outline" 
                    onClick={() => setCurrentPart(Math.max(0, currentPart - 1))}
                    disabled={currentPart === 0}
                  >
                    Previous Part
                  </Button>
                  <Button 
                    onClick={() => {
                      if (currentPart < test.parts.length - 1) {
                        setCurrentPart(currentPart + 1);
                      } else {
                        setActiveTest(null);
                        toast({
                          title: "Speaking practice completed!",
                          description: "You've practiced all three parts of IELTS Speaking"
                        });
                      }
                    }}
                    className="bg-purple-600 text-white"
                  >
                    {currentPart === test.parts.length - 1 ? 'Complete Practice' : 'Next Part'}
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    );
  };

  const renderTest = () => {
    if (!activeTest) return null;
    
    if (testCompleted) {
      return (
        <div className="bg-green-50 rounded-xl p-8 text-center animate-fade-in">
          <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
            <Award className="text-green-600" size={32} />
          </div>
          <h3 className="text-xl font-semibold text-green-800 mb-2">Test B1-B2 hoàn thành!</h3>
          <p className="text-green-600">Kết quả đã được phân tích và lưu vào hồ sơ học tập của bạn.</p>
        </div>
      );
    }
    
    switch (activeTest) {
      case 'listening':
        return renderListeningTest();
      case 'reading':
        return renderReadingTest();
      case 'writing':
        return renderWritingPractice();
      case 'speaking':
        return renderSpeakingPractice();
      default:
        return null;
    }
  };

  return (
    <div className="space-y-6">
      {/* B1-B2 Target Stats */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card className="border-l-4 border-l-blue-500">
          <CardContent className="p-4">
            <div className="flex items-center">
              <div className="w-10 h-10 bg-blue-100 rounded-lg flex items-center justify-center">
                <Target className="text-blue-600" size={20} />
              </div>
              <div className="ml-3">
                <p className="text-sm text-gray-500">Target Band</p>
                <p className="text-xl font-bold text-gray-900">6.5-7.0</p>
              </div>
            </div>
          </CardContent>
        </Card>
        
        <Card className="border-l-4 border-l-green-500">
          <CardContent className="p-4">
            <div className="flex items-center">
              <div className="w-10 h-10 bg-green-100 rounded-lg flex items-center justify-center">
                <TrendingUp className="text-green-600" size={20} />
              </div>
              <div className="ml-3">
                <p className="text-sm text-gray-500">Current Level</p>
                <p className="text-xl font-bold text-gray-900">B1-B2</p>
              </div>
            </div>
          </CardContent>
        </Card>
        
        <Card className="border-l-4 border-l-purple-500">
          <CardContent className="p-4">
            <div className="flex items-center">
              <div className="w-10 h-10 bg-purple-100 rounded-lg flex items-center justify-center">
                <Clock className="text-purple-600" size={20} />
              </div>
              <div className="ml-3">
                <p className="text-sm text-gray-500">Study Time</p>
                <p className="text-xl font-bold text-gray-900">45h</p>
              </div>
            </div>
          </CardContent>
        </Card>
        
        <Card className="border-l-4 border-l-orange-500">
          <CardContent className="p-4">
            <div className="flex items-center">
              <div className="w-10 h-10 bg-orange-100 rounded-lg flex items-center justify-center">
                <Star className="text-orange-600" size={20} />
              </div>
              <div className="ml-3">
                <p className="text-sm text-gray-500">Progress</p>
                <p className="text-xl font-bold text-gray-900">78%</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
      
      {/* Main Practice Area */}
      <div className="bg-white rounded-2xl shadow-sm border border-gray-100 overflow-hidden">
        <div className="study-pink-gradient px-6 py-5 text-white">
          <h2 className="text-xl font-semibold">IELTS Practice - B1/B2 Level (Target: 6.5-7.0)</h2>
          <p className="text-pink-100 text-sm mt-1">Luyện tập được thiết kế riêng cho học viên trình độ B1-B2</p>
        </div>
        
        <div className="p-6">
          {activeTest ? (
            renderTest()
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {Object.entries(ieltsB1B2Content).map(([testType, test]) => {
                const IconComponent = test.icon;
                return (
                  <Card key={testType} className="hover:shadow-lg transition-shadow cursor-pointer group" onClick={() => startTest(testType)}>
                    <CardContent className="p-6">
                      <div className="flex items-start space-x-4">
                        <div className={`w-12 h-12 ${test.color} rounded-lg flex items-center justify-center group-hover:scale-110 transition-transform`}>
                          <IconComponent size={24} />
                        </div>
                        <div className="flex-1">
                          <h3 className="font-semibold text-gray-900 mb-1">{test.title}</h3>
                          <p className="text-sm text-gray-600 mb-2">{test.description}</p>
                          
                          <div className="flex items-center gap-4 text-xs text-gray-500 mb-3">
                            <span>🎯 {test.targetBand}</span>
                            <span>⏱️ {test.duration}</span>
                            <span>📝 {test.questions} câu hỏi</span>
                          </div>
                          
                          <div className="space-y-1">
                            <p className="text-xs font-medium text-gray-700">Kỹ năng luyện tập:</p>
                            <div className="flex flex-wrap gap-1">
                              {test.skills.slice(0, 2).map((skill, i) => (
                                <Badge key={i} variant="outline" className="text-xs">
                                  {skill}
                                </Badge>
                              ))}
                              {test.skills.length > 2 && (
                                <Badge variant="outline" className="text-xs">
                                  +{test.skills.length - 2} more
                                </Badge>
                              )}
                            </div>
                          </div>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                );
              })}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}