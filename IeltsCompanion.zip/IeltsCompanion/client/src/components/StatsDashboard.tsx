import { useQuery } from "@tanstack/react-query";
import { useEffect, useRef } from "react";
import { Chart, registerables } from "chart.js";
import type { Task, StudyStat } from "@shared/schema";

Chart.register(...registerables);

export default function StatsDashboard() {
  const chartRef = useRef<HTMLCanvasElement>(null);
  const chartInstanceRef = useRef<Chart | null>(null);

  const { data: tasks = [] } = useQuery<Task[]>({
    queryKey: ['/api/tasks'],
  });

  const { data: studyStats = [] } = useQuery<StudyStat[]>({
    queryKey: ['/api/study-stats'],
  });

  useEffect(() => {
    if (!chartRef.current) return;

    // Destroy previous chart instance
    if (chartInstanceRef.current) {
      chartInstanceRef.current.destroy();
    }

    const completedTasks = tasks.filter(task => task.completed).length;
    const totalTasks = tasks.length;

    const ctx = chartRef.current.getContext('2d');
    if (!ctx) return;

    chartInstanceRef.current = new Chart(ctx, {
      type: 'doughnut',
      data: {
        labels: ['Hoàn thành', 'Chưa hoàn thành'],
        datasets: [{
          data: [completedTasks, totalTasks - completedTasks],
          backgroundColor: ['#10B981', '#F3F4F6'],
          borderWidth: 0,
          cutout: '70%'
        }]
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
          legend: {
            position: 'bottom',
            labels: {
              padding: 20,
              usePointStyle: true,
              font: {
                size: 12,
                family: 'Inter'
              }
            }
          }
        }
      }
    });

    return () => {
      if (chartInstanceRef.current) {
        chartInstanceRef.current.destroy();
      }
    };
  }, [tasks]);

  const completedToday = tasks.filter(task => task.completed).length;
  const totalToday = tasks.length;
  const vocabularyLearned = studyStats.reduce((sum, stat) => sum + stat.vocabularyLearned, 0);
  const weeklyTime = studyStats.reduce((sum, stat) => sum + stat.studyTimeMinutes, 0) / 60;

  return (
    <div className="bg-white rounded-2xl shadow-sm border border-gray-100 overflow-hidden">
      <div className="px-6 py-4 border-b border-gray-100">
        <h3 className="text-lg font-semibold text-gray-900">Thống kê học tập</h3>
      </div>
      
      <div className="p-6">
        <div className="mb-6">
          <canvas ref={chartRef} className="w-full h-48"></canvas>
        </div>
        
        {/* Quick Stats */}
        <div className="space-y-3">
          <div className="flex items-center justify-between">
            <span className="text-sm text-gray-600">Hoàn thành hôm nay</span>
            <span className="font-semibold text-green-600">
              {completedToday}/{totalToday}
            </span>
          </div>
          <div className="flex items-center justify-between">
            <span className="text-sm text-gray-600">Từ vựng đã học</span>
            <span className="font-semibold text-blue-600">
              {vocabularyLearned}
            </span>
          </div>
          <div className="flex items-center justify-between">
            <span className="text-sm text-gray-600">Thời gian tuần này</span>
            <span className="font-semibold text-pink-600">
              {weeklyTime.toFixed(1)}h
            </span>
          </div>
        </div>
      </div>
    </div>
  );
}
