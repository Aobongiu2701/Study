import { useState } from "react";
import { useMutation } from "@tanstack/react-query";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { Headphones, BookOpen, PenTool, Mic, TrendingUp, Clock, Flame } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useToast } from "@/hooks/use-toast";
import type { InsertTestResult } from "@shared/schema";

interface TestQuestion {
  id: number;
  question: string;
  options: string[];
  correctAnswer: string;
}

const testContent = {
  listening: {
    icon: Headphones,
    title: "Listening Test",
    duration: "10 phút",
    questions: 5,
    color: "bg-blue-100 text-blue-600",
    questions_data: [
      {
        id: 1,
        question: "What is the main topic of the conversation?",
        options: ["A) Weather forecast", "B) Travel plans", "C) Work schedule"],
        correctAnswer: "B"
      }
    ]
  },
  reading: {
    icon: BookOpen,
    title: "Reading Test",
    duration: "15 phút",
    questions: 5,
    color: "bg-green-100 text-green-600",
    questions_data: [
      {
        id: 1,
        question: "According to the passage, what is the main cause of climate change?",
        options: ["A) Natural weather patterns", "B) Greenhouse gases from human activities", "C) Solar radiation changes"],
        correctAnswer: "B"
      }
    ]
  },
  writing: {
    icon: PenTool,
    title: "Writing Practice",
    duration: "60 phút",
    questions: 2,
    color: "bg-yellow-100 text-yellow-600",
    questions_data: []
  },
  speaking: {
    icon: Mic,
    title: "Speaking Practice",
    duration: "15 phút",
    questions: 3,
    color: "bg-purple-100 text-purple-600",
    questions_data: []
  }
};

export default function IELTSLearning() {
  const [activeTest, setActiveTest] = useState<string | null>(null);
  const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0);
  const [userAnswers, setUserAnswers] = useState<Record<number, string>>({});
  const [testCompleted, setTestCompleted] = useState(false);
  const { toast } = useToast();

  const submitTestMutation = useMutation({
    mutationFn: async (result: InsertTestResult) => {
      const response = await apiRequest('POST', '/api/test-results', result);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/test-results'] });
      toast({
        title: "Hoàn thành!",
        description: "Kết quả bài test đã được lưu",
      });
    },
  });

  const startTest = (testType: string) => {
    setActiveTest(testType);
    setCurrentQuestionIndex(0);
    setUserAnswers({});
    setTestCompleted(false);
  };

  const selectAnswer = (questionId: number, answer: string) => {
    setUserAnswers(prev => ({
      ...prev,
      [questionId]: answer
    }));
  };

  const submitTest = () => {
    if (!activeTest) return;
    
    const test = testContent[activeTest as keyof typeof testContent];
    const correctAnswers = test.questions_data.filter(q => 
      userAnswers[q.id] === q.correctAnswer
    ).length;
    
    const score = Math.round((correctAnswers / test.questions_data.length) * 10);
    
    submitTestMutation.mutate({
      testType: activeTest,
      score,
      totalQuestions: test.questions_data.length,
      answers: userAnswers
    });
    
    setTestCompleted(true);
    setTimeout(() => {
      setActiveTest(null);
      setTestCompleted(false);
    }, 3000);
  };

  const renderTest = () => {
    if (!activeTest) return null;
    
    const test = testContent[activeTest as keyof typeof testContent];
    
    if (testCompleted) {
      return (
        <div className="bg-green-50 rounded-xl p-8 text-center animate-fade-in">
          <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
            <TrendingUp className="text-green-600" size={32} />
          </div>
          <h3 className="text-xl font-semibold text-green-800 mb-2">Hoàn thành bài test!</h3>
          <p className="text-green-600">Kết quả đã được lưu và thêm vào thống kê của bạn.</p>
        </div>
      );
    }
    
    if (test.questions_data.length === 0) {
      return (
        <div className="bg-gray-50 rounded-xl p-8 text-center">
          <h3 className="text-lg font-semibold mb-4">{test.title}</h3>
          <p className="text-gray-600 mb-4">Tính năng này sẽ sớm được cập nhật!</p>
          <Button onClick={() => setActiveTest(null)} variant="outline">
            Quay lại
          </Button>
        </div>
      );
    }

    return (
      <div className="space-y-6 animate-slide-in">
        <div className="flex items-center justify-between">
          <h3 className="text-lg font-semibold">{test.title}</h3>
          <Button onClick={() => setActiveTest(null)} variant="outline" size="sm">
            Đóng
          </Button>
        </div>
        
        {activeTest === 'listening' && (
          <div className="bg-blue-50 rounded-lg p-4">
            <audio controls className="w-full mb-4">
              <source src="https://www.soundjay.com/misc/sounds/bell-ringing-05.wav" type="audio/wav" />
              Trình duyệt không hỗ trợ audio.
            </audio>
            <p className="text-sm text-gray-600">Nghe audio và trả lời các câu hỏi bên dưới:</p>
          </div>
        )}
        
        {activeTest === 'reading' && (
          <div className="bg-green-50 rounded-lg p-4">
            <div className="bg-white p-4 rounded-lg">
              <p className="text-sm leading-relaxed">
                Climate change represents one of the most pressing challenges of our time. Scientists worldwide have documented rising global temperatures, melting ice caps, and increasingly frequent extreme weather events. The primary cause is the increased concentration of greenhouse gases in the atmosphere, largely due to human activities such as burning fossil fuels and deforestation.
              </p>
            </div>
          </div>
        )}
        
        <div className="space-y-4">
          {test.questions_data.map((question, index) => (
            <div key={question.id} className="p-4 bg-white rounded-lg border border-gray-200">
              <p className="font-medium mb-3">{index + 1}. {question.question}</p>
              <div className="space-y-2">
                {question.options.map((option) => (
                  <label key={option} className="flex items-center cursor-pointer">
                    <input
                      type="radio"
                      name={`question-${question.id}`}
                      value={option.charAt(0)}
                      checked={userAnswers[question.id] === option.charAt(0)}
                      onChange={(e) => selectAnswer(question.id, e.target.value)}
                      className="mr-3 text-blue-600"
                    />
                    <span>{option}</span>
                  </label>
                ))}
              </div>
            </div>
          ))}
          
          <Button
            onClick={submitTest}
            disabled={Object.keys(userAnswers).length !== test.questions_data.length || submitTestMutation.isPending}
            className="w-full study-blue-gradient text-white"
          >
            {submitTestMutation.isPending ? 'Đang nộp bài...' : 'Nộp bài'}
          </Button>
        </div>
      </div>
    );
  };

  return (
    <div className="space-y-6">
      {/* Quick Stats */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div className="bg-white rounded-xl p-6 border border-gray-100">
          <div className="flex items-center">
            <div className="w-12 h-12 bg-green-100 rounded-lg flex items-center justify-center">
              <TrendingUp className="text-green-600" size={20} />
            </div>
            <div className="ml-4">
              <p className="text-sm text-gray-500">Điểm trung bình</p>
              <p className="text-2xl font-bold text-gray-900">7.5</p>
            </div>
          </div>
        </div>
        
        <div className="bg-white rounded-xl p-6 border border-gray-100">
          <div className="flex items-center">
            <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center">
              <Clock className="text-blue-600" size={20} />
            </div>
            <div className="ml-4">
              <p className="text-sm text-gray-500">Thời gian học</p>
              <p className="text-2xl font-bold text-gray-900">2.5h</p>
            </div>
          </div>
        </div>
        
        <div className="bg-white rounded-xl p-6 border border-gray-100">
          <div className="flex items-center">
            <div className="w-12 h-12 bg-purple-100 rounded-lg flex items-center justify-center">
              <Flame className="text-purple-600" size={20} />
            </div>
            <div className="ml-4">
              <p className="text-sm text-gray-500">Streak</p>
              <p className="text-2xl font-bold text-gray-900">12</p>
            </div>
          </div>
        </div>
      </div>
      
      {/* IELTS Practice */}
      <div className="bg-white rounded-2xl shadow-sm border border-gray-100 overflow-hidden">
        <div className="study-pink-gradient px-6 py-5 text-white">
          <h2 className="text-xl font-semibold">Luyện tập IELTS</h2>
          <p className="text-pink-100 text-sm mt-1">Cải thiện kỹ năng với các bài test thực tế</p>
        </div>
        
        <div className="p-6">
          {activeTest ? (
            renderTest()
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {Object.entries(testContent).map(([testType, test]) => {
                const IconComponent = test.icon;
                return (
                  <button
                    key={testType}
                    onClick={() => startTest(testType)}
                    className="p-4 border-2 border-gray-200 rounded-xl hover:border-blue-500 hover:bg-blue-50 transition-all text-left group"
                  >
                    <div className="flex items-center space-x-3">
                      <div className={`w-10 h-10 ${test.color} rounded-lg flex items-center justify-center group-hover:scale-110 transition-transform`}>
                        <IconComponent size={20} />
                      </div>
                      <div>
                        <h3 className="font-semibold text-gray-900">{test.title}</h3>
                        <p className="text-sm text-gray-500">{test.questions} câu hỏi • {test.duration}</p>
                      </div>
                    </div>
                  </button>
                );
              })}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
