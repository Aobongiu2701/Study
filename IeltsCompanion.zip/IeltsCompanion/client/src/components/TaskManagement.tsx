import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { Plus, Paperclip, Download, Trash2, Calendar, ListTodo } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { useToast } from "@/hooks/use-toast";
import type { Task, InsertTask } from "@shared/schema";

interface TaskManagementProps {
  currentDate: string;
}

export default function TaskManagement({ currentDate }: TaskManagementProps) {
  const [isAddingTask, setIsAddingTask] = useState(false);
  const [newTaskTitle, setNewTaskTitle] = useState("");
  const [newTaskPriority, setNewTaskPriority] = useState("Trung bình");
  const [newTaskTime, setNewTaskTime] = useState(30);
  const { toast } = useToast();

  const { data: tasks = [], isLoading } = useQuery<Task[]>({
    queryKey: ['/api/tasks'],
  });

  const createTaskMutation = useMutation({
    mutationFn: async (task: InsertTask) => {
      const response = await apiRequest('POST', '/api/tasks', task);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/tasks'] });
      setIsAddingTask(false);
      setNewTaskTitle("");
      setNewTaskPriority("Trung bình");
      setNewTaskTime(30);
      toast({
        title: "Thành công",
        description: "Đã thêm công việc mới",
      });
    },
  });

  const updateTaskMutation = useMutation({
    mutationFn: async ({ id, updates }: { id: number; updates: Partial<Task> }) => {
      const response = await apiRequest('PATCH', `/api/tasks/${id}`, updates);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/tasks'] });
    },
  });

  const deleteTaskMutation = useMutation({
    mutationFn: async (id: number) => {
      const response = await apiRequest('DELETE', `/api/tasks/${id}`);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/tasks'] });
      toast({
        title: "Đã xóa",
        description: "Công việc đã được xóa",
      });
    },
  });

  const handleAddTask = () => {
    if (!newTaskTitle.trim()) return;
    
    createTaskMutation.mutate({
      title: newTaskTitle,
      priority: newTaskPriority,
      estimatedTime: newTaskTime,
      completed: false,
    });
  };

  const handleToggleTask = (taskId: number, completed: boolean) => {
    updateTaskMutation.mutate({
      id: taskId,
      updates: { completed }
    });
  };

  const handleDeleteTask = (taskId: number) => {
    if (confirm('Bạn có chắc muốn xóa công việc này?')) {
      deleteTaskMutation.mutate(taskId);
    }
  };

  const handleImageUpload = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    const formData = new FormData();
    formData.append('image', file);

    try {
      const response = await fetch('/api/upload', {
        method: 'POST',
        body: formData,
      });
      
      if (response.ok) {
        toast({
          title: "Thành công",
          description: "Đã tải lên hình ảnh",
        });
      }
    } catch (error) {
      toast({
        title: "Lỗi",
        description: "Không thể tải lên hình ảnh",
        variant: "destructive"
      });
    }
  };

  const handleExportTasks = () => {
    const data = {
      tasks,
      exportDate: new Date().toISOString()
    };
    
    const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `studyflow-backup-${new Date().toISOString().split('T')[0]}.json`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const completedTasks = tasks.filter(task => task.completed).length;
  const totalTasks = tasks.length;
  const progressPercentage = totalTasks > 0 ? (completedTasks / totalTasks) * 100 : 0;

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case 'Cao': return 'bg-red-100 text-red-700';
      case 'Trung bình': return 'bg-yellow-100 text-yellow-700';
      case 'Thấp': return 'bg-green-100 text-green-700';
      default: return 'bg-gray-100 text-gray-700';
    }
  };

  if (isLoading) {
    return (
      <div className="bg-white rounded-2xl shadow-sm border border-gray-100 overflow-hidden">
        <div className="p-6">
          <div className="animate-pulse space-y-4">
            <div className="h-4 bg-gray-200 rounded w-3/4"></div>
            <div className="h-4 bg-gray-200 rounded w-1/2"></div>
            <div className="h-16 bg-gray-200 rounded"></div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="bg-white rounded-2xl shadow-sm border border-gray-100 overflow-hidden">
      {/* Header Section */}
      <div className="study-blue-gradient px-6 py-5 text-white">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-xl font-semibold">Kế hoạch hôm nay</h2>
            <p className="text-blue-100 text-sm mt-1">{currentDate}</p>
          </div>
          <div className="bg-white/20 rounded-lg px-3 py-2">
            <Calendar size={20} />
          </div>
        </div>
      </div>
      
      {/* Progress Section */}
      <div className="px-6 py-4 bg-gray-50 border-b border-gray-100">
        <div className="flex items-center justify-between mb-2">
          <span className="text-sm font-medium text-gray-700">Tiến độ hôm nay</span>
          <span className="text-sm text-gray-500">{completedTasks}/{totalTasks} công việc</span>
        </div>
        <div className="w-full bg-gray-200 rounded-full h-2">
          <div 
            className="progress-bar h-2 rounded-full" 
            style={{ width: `${progressPercentage}%` }}
          />
        </div>
      </div>
      
      {/* Action Buttons */}
      <div className="px-6 py-4 border-b border-gray-100">
        <div className="flex flex-wrap gap-3">
          <input 
            type="file" 
            id="imageUpload" 
            accept="image/*" 
            className="hidden" 
            onChange={handleImageUpload}
          />
          <Button
            variant="outline"
            onClick={() => document.getElementById('imageUpload')?.click()}
            className="bg-green-50 text-green-700 border-green-200 hover:bg-green-100"
          >
            <Paperclip size={16} className="mr-2" />
            Đính kèm
          </Button>
          <Button
            onClick={() => setIsAddingTask(true)}
            className="study-blue-gradient text-white hover:opacity-90"
          >
            <Plus size={16} className="mr-2" />
            Thêm công việc
          </Button>
          <Button
            variant="outline"
            onClick={handleExportTasks}
            className="bg-gray-100 text-gray-700 hover:bg-gray-200"
          >
            <Download size={16} className="mr-2" />
            Xuất dữ liệu
          </Button>
        </div>
      </div>
      
      {/* Add Task Form */}
      {isAddingTask && (
        <div className="px-6 py-4 bg-blue-50 border-b border-gray-100 animate-slide-in">
          <div className="space-y-3">
            <Input
              placeholder="Nhập tên công việc..."
              value={newTaskTitle}
              onChange={(e) => setNewTaskTitle(e.target.value)}
              className="bg-white"
            />
            <div className="flex gap-3">
              <select
                value={newTaskPriority}
                onChange={(e) => setNewTaskPriority(e.target.value)}
                className="px-3 py-2 border border-gray-300 rounded-lg bg-white"
              >
                <option value="Thấp">Thấp</option>
                <option value="Trung bình">Trung bình</option>
                <option value="Cao">Cao</option>
              </select>
              <input
                type="number"
                placeholder="Thời gian (phút)"
                value={newTaskTime}
                onChange={(e) => setNewTaskTime(parseInt(e.target.value) || 30)}
                className="px-3 py-2 border border-gray-300 rounded-lg bg-white w-32"
              />
            </div>
            <div className="flex gap-2">
              <Button
                onClick={handleAddTask}
                disabled={createTaskMutation.isPending}
                className="study-blue-gradient text-white"
              >
                {createTaskMutation.isPending ? 'Đang thêm...' : 'Thêm'}
              </Button>
              <Button
                variant="outline"
                onClick={() => setIsAddingTask(false)}
              >
                Hủy
              </Button>
            </div>
          </div>
        </div>
      )}
      
      {/* Task List */}
      <div className="px-6 py-4">
        {tasks.length === 0 ? (
          <div className="text-center py-12">
            <div className="w-16 h-16 mx-auto bg-gray-100 rounded-full flex items-center justify-center mb-4">
              <ListTodo className="text-gray-400" size={24} />
            </div>
            <p className="text-gray-500">Chưa có công việc nào. Hãy thêm công việc đầu tiên!</p>
          </div>
        ) : (
          <div className="space-y-3">
            {tasks.map((task) => (
              <div
                key={task.id}
                className="task-item p-4 bg-gray-50 rounded-xl border border-gray-100 flex items-center space-x-4 animate-slide-in"
              >
                <input
                  type="checkbox"
                  checked={task.completed}
                  onChange={(e) => handleToggleTask(task.id, e.target.checked)}
                  className="w-5 h-5 text-blue-600 rounded focus:ring-2 focus:ring-blue-500"
                />
                <div className="flex-1">
                  <h4 className={`font-medium text-gray-900 ${task.completed ? 'line-through' : ''}`}>
                    {task.title}
                  </h4>
                  <p className="text-sm text-gray-500 mt-1">
                    Ưu tiên: {task.priority} • Thời gian: {task.estimatedTime} phút
                  </p>
                </div>
                <div className="flex items-center space-x-2">
                  <span className={`px-2 py-1 text-xs rounded-full ${getPriorityColor(task.priority)}`}>
                    {task.priority}
                  </span>
                  <button
                    onClick={() => handleDeleteTask(task.id)}
                    className="text-gray-400 hover:text-red-500 transition-colors"
                    disabled={deleteTaskMutation.isPending}
                  >
                    <Trash2 size={16} />
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
