import { Chart, registerables } from 'chart.js';

Chart.register(...registerables);

export const defaultChartOptions = {
  responsive: true,
  maintainAspectRatio: false,
  plugins: {
    legend: {
      position: 'bottom' as const,
      labels: {
        padding: 20,
        usePointStyle: true,
        font: {
          size: 12,
          family: 'Inter, system-ui, sans-serif'
        }
      }
    }
  }
};

export const doughnutChartOptions = {
  ...defaultChartOptions,
  cutout: '70%'
};

export const studyFlowColors = {
  primary: '#3B82F6',
  secondary: '#EC4899',
  success: '#10B981',
  warning: '#F59E0B',
  gray: '#F3F4F6'
};
