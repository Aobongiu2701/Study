import { 
  tasks, flashcards, testResults, studyStats,
  type Task, type InsertTask,
  type Flashcard, type InsertFlashcard,
  type TestResult, type InsertTestResult,
  type StudyStat, type InsertStudyStat
} from "@shared/schema";

export interface IStorage {
  // Tasks
  getTasks(): Promise<Task[]>;
  createTask(task: InsertTask): Promise<Task>;
  updateTask(id: number, updates: Partial<Task>): Promise<Task>;
  deleteTask(id: number): Promise<void>;

  // Flashcards
  getFlashcards(): Promise<Flashcard[]>;
  createFlashcard(flashcard: InsertFlashcard): Promise<Flashcard>;
  updateFlashcard(id: number, updates: Partial<Flashcard>): Promise<Flashcard>;
  getNextFlashcard(): Promise<Flashcard | null>;

  // Test Results
  getTestResults(): Promise<TestResult[]>;
  createTestResult(result: InsertTestResult): Promise<TestResult>;
  getTestResultsByType(testType: string): Promise<TestResult[]>;

  // Study Stats
  getStudyStats(): Promise<StudyStat[]>;
  createOrUpdateStudyStat(stat: InsertStudyStat): Promise<StudyStat>;
  getStudyStatByDate(date: string): Promise<StudyStat | null>;
}

export class MemStorage implements IStorage {
  private tasks: Map<number, Task>;
  private flashcards: Map<number, Flashcard>;
  private testResults: Map<number, TestResult>;
  private studyStats: Map<string, StudyStat>;
  private currentTaskId: number;
  private currentFlashcardId: number;
  private currentTestResultId: number;
  private currentStudyStatId: number;

  constructor() {
    this.tasks = new Map();
    this.flashcards = new Map();
    this.testResults = new Map();
    this.studyStats = new Map();
    this.currentTaskId = 1;
    this.currentFlashcardId = 1;
    this.currentTestResultId = 1;
    this.currentStudyStatId = 1;

    // Initialize with some default flashcards
    this.initializeDefaultFlashcards();
  }

  private initializeDefaultFlashcards() {
    const defaultFlashcards = [
      {
        word: "Ephemeral",
        meaning: "Ngắn ngủi, tạm thời",
        example: "Beauty is ephemeral and fleeting.",
        difficulty: 1
      },
      {
        word: "Ubiquitous",
        meaning: "Có mặt khắp nơi",
        example: "Smartphones have become ubiquitous in modern society.",
        difficulty: 1
      },
      {
        word: "Meticulous",
        meaning: "Tỉ mỉ, cẩn thận",
        example: "She was meticulous in her research.",
        difficulty: 1
      }
    ];

    defaultFlashcards.forEach(card => {
      const flashcard: Flashcard = {
        id: this.currentFlashcardId++,
        ...card,
        nextReview: new Date(),
        reviewCount: 0
      };
      this.flashcards.set(flashcard.id, flashcard);
    });
  }

  // Tasks
  async getTasks(): Promise<Task[]> {
    return Array.from(this.tasks.values()).sort((a, b) => 
      new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
    );
  }

  async createTask(task: InsertTask): Promise<Task> {
    const newTask: Task = {
      id: this.currentTaskId++,
      title: task.title,
      description: task.description || null,
      priority: task.priority || "Trung bình",
      category: task.category || "Khác",
      estimatedTime: task.estimatedTime || 30,
      actualTime: task.actualTime || 0,
      dueDate: task.dueDate || null,
      tags: task.tags || [],
      subtasks: task.subtasks || [],
      attachments: task.attachments || [],
      results: task.results || [],
      completed: task.completed || false,
      completedAt: null,
      createdAt: new Date()
    };
    this.tasks.set(newTask.id, newTask);
    return newTask;
  }

  async updateTask(id: number, updates: Partial<Task>): Promise<Task> {
    const task = this.tasks.get(id);
    if (!task) throw new Error('Task not found');
    
    const updatedTask = { 
      ...task, 
      ...updates,
      completedAt: updates.completed && !task.completed ? new Date() : 
                   updates.completed === false ? null : task.completedAt
    };
    this.tasks.set(id, updatedTask);
    return updatedTask;
  }

  async deleteTask(id: number): Promise<void> {
    this.tasks.delete(id);
  }

  // Flashcards
  async getFlashcards(): Promise<Flashcard[]> {
    return Array.from(this.flashcards.values());
  }

  async createFlashcard(flashcard: InsertFlashcard): Promise<Flashcard> {
    const newFlashcard: Flashcard = {
      id: this.currentFlashcardId++,
      ...flashcard,
      nextReview: new Date(),
      reviewCount: 0
    };
    this.flashcards.set(newFlashcard.id, newFlashcard);
    return newFlashcard;
  }

  async updateFlashcard(id: number, updates: Partial<Flashcard>): Promise<Flashcard> {
    const flashcard = this.flashcards.get(id);
    if (!flashcard) throw new Error('Flashcard not found');
    
    const updatedFlashcard = { ...flashcard, ...updates };
    this.flashcards.set(id, updatedFlashcard);
    return updatedFlashcard;
  }

  async getNextFlashcard(): Promise<Flashcard | null> {
    const flashcards = Array.from(this.flashcards.values());
    const now = new Date();
    
    // Find flashcards due for review
    const dueFlashcards = flashcards.filter(card => 
      new Date(card.nextReview) <= now
    );
    
    if (dueFlashcards.length > 0) {
      return dueFlashcards[Math.floor(Math.random() * dueFlashcards.length)];
    }
    
    // If no cards are due, return a random one
    return flashcards.length > 0 
      ? flashcards[Math.floor(Math.random() * flashcards.length)]
      : null;
  }

  // Test Results
  async getTestResults(): Promise<TestResult[]> {
    return Array.from(this.testResults.values()).sort((a, b) => 
      new Date(b.completedAt).getTime() - new Date(a.completedAt).getTime()
    );
  }

  async createTestResult(result: InsertTestResult): Promise<TestResult> {
    const newResult: TestResult = {
      id: this.currentTestResultId++,
      ...result,
      completedAt: new Date()
    };
    this.testResults.set(newResult.id, newResult);
    return newResult;
  }

  async getTestResultsByType(testType: string): Promise<TestResult[]> {
    return Array.from(this.testResults.values())
      .filter(result => result.testType === testType)
      .sort((a, b) => new Date(b.completedAt).getTime() - new Date(a.completedAt).getTime());
  }

  // Study Stats
  async getStudyStats(): Promise<StudyStat[]> {
    return Array.from(this.studyStats.values());
  }

  async createOrUpdateStudyStat(stat: InsertStudyStat): Promise<StudyStat> {
    const existing = this.studyStats.get(stat.date);
    
    if (existing) {
      const updated = { ...existing, ...stat };
      this.studyStats.set(stat.date, updated);
      return updated;
    } else {
      const newStat: StudyStat = {
        id: this.currentStudyStatId++,
        ...stat
      };
      this.studyStats.set(stat.date, newStat);
      return newStat;
    }
  }

  async getStudyStatByDate(date: string): Promise<StudyStat | null> {
    return this.studyStats.get(date) || null;
  }
}

export const storage = new MemStorage();
