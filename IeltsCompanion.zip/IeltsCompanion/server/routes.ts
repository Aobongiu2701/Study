import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertTaskSchema, insertFlashcardSchema, insertTestResultSchema, insertStudyStatSchema } from "@shared/schema";
import multer from "multer";

const upload = multer({ storage: multer.memoryStorage() });

export async function registerRoutes(app: Express): Promise<Server> {
  // Tasks routes
  app.get("/api/tasks", async (req, res) => {
    try {
      const tasks = await storage.getTasks();
      res.json(tasks);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch tasks" });
    }
  });

  app.post("/api/tasks", async (req, res) => {
    try {
      const taskData = insertTaskSchema.parse(req.body);
      const task = await storage.createTask(taskData);
      res.json(task);
    } catch (error) {
      res.status(400).json({ message: "Invalid task data" });
    }
  });

  app.patch("/api/tasks/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const updates = req.body;
      const task = await storage.updateTask(id, updates);
      res.json(task);
    } catch (error) {
      res.status(400).json({ message: "Failed to update task" });
    }
  });

  app.delete("/api/tasks/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      await storage.deleteTask(id);
      res.json({ success: true });
    } catch (error) {
      res.status(400).json({ message: "Failed to delete task" });
    }
  });

  // Flashcards routes
  app.get("/api/flashcards", async (req, res) => {
    try {
      const flashcards = await storage.getFlashcards();
      res.json(flashcards);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch flashcards" });
    }
  });

  app.get("/api/flashcards/next", async (req, res) => {
    try {
      const flashcard = await storage.getNextFlashcard();
      res.json(flashcard);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch next flashcard" });
    }
  });

  app.patch("/api/flashcards/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const updates = req.body;
      const flashcard = await storage.updateFlashcard(id, updates);
      res.json(flashcard);
    } catch (error) {
      res.status(400).json({ message: "Failed to update flashcard" });
    }
  });

  // Test results routes
  app.get("/api/test-results", async (req, res) => {
    try {
      const results = await storage.getTestResults();
      res.json(results);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch test results" });
    }
  });

  app.post("/api/test-results", async (req, res) => {
    try {
      const resultData = insertTestResultSchema.parse(req.body);
      const result = await storage.createTestResult(resultData);
      res.json(result);
    } catch (error) {
      res.status(400).json({ message: "Invalid test result data" });
    }
  });

  // Study stats routes
  app.get("/api/study-stats", async (req, res) => {
    try {
      const stats = await storage.getStudyStats();
      res.json(stats);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch study stats" });
    }
  });

  app.post("/api/study-stats", async (req, res) => {
    try {
      const statData = insertStudyStatSchema.parse(req.body);
      const stat = await storage.createOrUpdateStudyStat(statData);
      res.json(stat);
    } catch (error) {
      res.status(400).json({ message: "Invalid study stat data" });
    }
  });

  // File upload route
  app.post("/api/upload", upload.single('image'), async (req, res) => {
    try {
      if (!req.file) {
        return res.status(400).json({ message: "No file uploaded" });
      }
      
      // Convert buffer to base64
      const base64 = req.file.buffer.toString('base64');
      const dataUrl = `data:${req.file.mimetype};base64,${base64}`;
      
      res.json({ url: dataUrl });
    } catch (error) {
      res.status(500).json({ message: "Failed to upload file" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
