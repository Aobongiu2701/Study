import { pgTable, text, serial, integer, boolean, timestamp, jsonb } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const tasks = pgTable("tasks", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  description: text("description"),
  priority: text("priority").notNull().default("Trung bình"),
  category: text("category").notNull().default("Khác"),
  estimatedTime: integer("estimated_time").notNull().default(30),
  actualTime: integer("actual_time").default(0),
  dueDate: timestamp("due_date"),
  tags: text("tags").array().default([]),
  subtasks: jsonb("subtasks").default([]),
  attachments: jsonb("attachments").default([]),
  results: jsonb("results").default([]),
  completed: boolean("completed").notNull().default(false),
  completedAt: timestamp("completed_at"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const flashcards = pgTable("flashcards", {
  id: serial("id").primaryKey(),
  word: text("word").notNull(),
  meaning: text("meaning").notNull(),
  example: text("example"),
  difficulty: integer("difficulty").notNull().default(1),
  nextReview: timestamp("next_review").notNull().defaultNow(),
  reviewCount: integer("review_count").notNull().default(0),
});

export const testResults = pgTable("test_results", {
  id: serial("id").primaryKey(),
  testType: text("test_type").notNull(), // listening, reading, writing, speaking
  score: integer("score").notNull(),
  totalQuestions: integer("total_questions").notNull(),
  completedAt: timestamp("completed_at").notNull().defaultNow(),
  answers: jsonb("answers"), // Store user answers
});

export const studyStats = pgTable("study_stats", {
  id: serial("id").primaryKey(),
  date: text("date").notNull(), // YYYY-MM-DD format
  tasksCompleted: integer("tasks_completed").notNull().default(0),
  totalTasks: integer("total_tasks").notNull().default(0),
  studyTimeMinutes: integer("study_time_minutes").notNull().default(0),
  vocabularyLearned: integer("vocabulary_learned").notNull().default(0),
  testsCompleted: integer("tests_completed").notNull().default(0),
});

export const insertTaskSchema = createInsertSchema(tasks).omit({
  id: true,
  createdAt: true,
  completedAt: true,
});

export const insertFlashcardSchema = createInsertSchema(flashcards).omit({
  id: true,
  nextReview: true,
  reviewCount: true,
});

export const insertTestResultSchema = createInsertSchema(testResults).omit({
  id: true,
  completedAt: true,
});

export const insertStudyStatSchema = createInsertSchema(studyStats).omit({
  id: true,
});

export type Task = typeof tasks.$inferSelect;
export type InsertTask = z.infer<typeof insertTaskSchema>;
export type Flashcard = typeof flashcards.$inferSelect;
export type InsertFlashcard = z.infer<typeof insertFlashcardSchema>;
export type TestResult = typeof testResults.$inferSelect;
export type InsertTestResult = z.infer<typeof insertTestResultSchema>;
export type StudyStat = typeof studyStats.$inferSelect;
export type InsertStudyStat = z.infer<typeof insertStudyStatSchema>;
